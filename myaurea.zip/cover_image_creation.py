from PIL import Image, ImageDraw, ImageFont

# Define the dimensions of your cover image (in pixels)
width = 1250
height = 1634

# Create a blank image with a white background
background_color = (255, 255, 255)
cover = Image.new("RGB", (width, height), background_color)

# Load a font (provide the path to a TrueType font file)
font = ImageFont.truetype("arial.ttf", size=72)

# Create a drawing context
draw = ImageDraw.Draw(cover)

# Define the title text
title_text = "Study of clinical patterns"
text_color = (0, 0, 0)  # Black

# Define the background box color
box_color = (200, 200, 200)  # Light gray

# Define the box dimensions
box_width = 1100
box_height = 400

# Calculate the position of the box
box_x = (width - box_width) / 2
box_y = (height - box_height) / 2

# Draw the background box
draw.rectangle([box_x, box_y, box_x + box_width, box_y + box_height], fill=box_color)

# Calculate the maximum width for the wrapped title text
max_text_width = box_width - 40  # Adjust the padding as needed

# Wrap the title text to fit within the box
lines = []
line = ""
for word in title_text.split():
    if font.getbbox(line + word)[2] <= max_text_width:
        line += word + " "
    else:
        lines.append(line)
        line = word + " "
lines.append(line)

# Calculate the total height of the wrapped text
text_height = len(lines) * font.getbbox(title_text)[3]

# Calculate the vertical position to center the text within the box
text_y = box_y + (box_height - text_height) / 2

# Draw the wrapped title text within the box
for line in lines:
    text_bbox = draw.textbbox((0, 0), line, font=font)
    text_width = text_bbox[2] - text_bbox[0]
    text_x = box_x + (box_width - text_width) / 2
    draw.text((text_x, text_y), line, fill=text_color, font=font)
    text_y += font.getbbox(title_text)[3]

# Open and resize the logo image (provide the path to your logo file)
logo = Image.open("logo.jpg")
new_logo_size = (30, 130)  # Adjust the desired size
logo = logo.resize(new_logo_size, Image.LANCZOS)  # Resizing with Lanczos resampling

# Paste the resized logo onto the cover image
cover.paste(logo, (80, 100))

# Save the cover image
cover.save("cover.png")

# Close the image
cover.close()
