from django.shortcuts import render
from inventory import models as IMODEL
from django.contrib.auth.models import User, Group
from django.db import connection
from django.shortcuts import redirect, render
from django.utils.timezone import datetime
from django.utils import timezone
import os, re, subprocess, json, shutil
from django.conf import settings
from django.views.generic import TemplateView
from django.contrib import messages
from django.http import (HttpResponse, HttpResponseBadRequest, HttpResponseForbidden)
from django.utils.datastructures import MultiValueDictKeyError
from django.core.exceptions import ObjectDoesNotExist
from .forms import*
from L2_edit import models as L2MODEL
from Typeset import models as TYPEMODEL
from bs4 import BeautifulSoup
#from lxml import etree


# Create your views here.
def l2_process(request):
    articles = L2MODEL.L2_Edit.objects.filter(filestatus = 'a')[:3]
    articles_inuse = L2MODEL.L2_Edit.objects.all()

    return render(request,'l2edit/l2edit_process.html',{'articles':articles, 'articles_inuse':articles_inuse})

def l2_start(request,pk):
    articles = L2MODEL.L2_Edit.objects.get(id=pk)
    a = articles.article_id
    article_id_ID = IMODEL.Inventory_Upload.objects.get(article_id=a).pk
#    print("This are articles by ravi:",articles)
    user = request.user
    u_name = User.objects.get(username=user).pk
    start_date = timezone.now().strftime('%Y-%m-%d %H:%M:%S')
    sta = 'i'
    act ='L2ED'
    articles.user_name=user
    articles.start_date=start_date
    articles.filestatus=sta
    cursor = connection.cursor()

    if TYPEMODEL.Typeset.objects.filter(article_id = article_id_ID).exists():
        messages.warning(request,"Some one Already Started Process Please choise another article ")
        return redirect('l2_process')
    else:
        l2_update_process= "UPDATE Process_status_process_status SET start_date='%s', filestatus='i', user_name_id='%s' WHERE article_id_id='%s' and activity='%s';"
        cursor.execute(l2_update_process%(start_date, u_name, article_id_ID, act))

        Copy_Edit_Completion_start_process1 = "INSERT INTO Process_status_production_hours (article_id_id,start_date,user_name_id,filestatus,activity) VALUES ('%s','%s','%s','%s','%s');"
        cursor.execute(Copy_Edit_Completion_start_process1%(article_id_ID,start_date,u_name,sta,act))
    articles.save()

    return redirect('l2_edit_file', article_num = article_id_ID, file_path=f'L2Edit/{a}/{a}.html')

def l2_inuse(request,pk):
    articles = L2MODEL.L2_Edit.objects.get(id=pk)
    a = articles.article_id
    article_id_ID = IMODEL.Inventory_Upload.objects.get(article_id=a).pk

    return redirect('l2_edit_file', article_num = article_id_ID, file_path=f'L2Edit/{a}/{a}.html')

def l2_edit_file(request, article_num, file_path):
    articles = L2MODEL.L2_Edit.objects.all()
#    user_name_id =  articles.user_name_id
    file_path = os.path.join(settings.STATIC_DIR, file_path)
    file_path = file_path.replace("\\", "/")
    with open(file_path, 'r', encoding='utf8') as f:
        file_content = f.read()
        file_content = file_content.replace('mml:','')
    return render(request, 'L2edit/l2_edit_file.html', {'file_content': file_content, 'article_num':article_num, 'file_path': file_path, 'articles':articles})

#def l2save_file(request, pk):
#    file_content = request.POST.get('file_content')
#    file_path = request.POST.get('file_path')
#    with open(file_path, 'w', encoding='utf8') as f:
#        f.write(file_content)
#    return redirect('l2_edit_file', article_num=pk, file_path=file_path)

import pathlib

def l2save_file(request, pk):
    file_content = request.POST.get('file_content')
    file_path = request.POST.get('file_path')

    try:
        path = pathlib.Path(file_path)
        with path.open('w', encoding='utf8') as f:
            f.write(file_content)
    except IOError as e:
        print('Exception occurred while saving the file:', e)
        # Handle the exception appropriately
        return HttpResponseServerError('Error occurred while saving the file.')

    return redirect('l2_edit_file', article_num=pk, file_path=file_path)


def l2_edit_update_pause_start(request, pk):
    try:
        articles = L2MODEL.L2_Edit.objects.get(id=pk)
        a = articles.article_id_id
        a_name = articles.article_id
        articles.filestatus = 'p'
        s = 'p'
        user = request.user
        
        articles.user_name=user
        u_name = User.objects.get(username=user).pk
        start_date = timezone.now().strftime('%Y-%m-%d %H:%M:%S')
        articles.start_date = start_date
        act = 'L2ED'
        inuse = 'i'        
        cursor = connection.cursor()
        l2_start_process_pause= "UPDATE Process_status_process_status SET filestatus='%s' WHERE article_id_id ='%s' AND activity='L2ED' AND user_name_id ='%s' AND filestatus ='%s';"
        cursor.execute(l2_start_process_pause%(s,a,u_name,inuse))

        l2_start_process_pause1 = "INSERT INTO Process_status_production_hours (article_id_id,start_date,pause_date,user_name_id,filestatus,activity) VALUES ('%s','%s','%s','%s','%s','%s');"
        cursor.execute(l2_start_process_pause1%(a,start_date,start_date,u_name,s,act))
    except ObjectDoesNotExist:
         return HttpResponse("<h2> current article is not present in database / already moved to next activity </h2>")
    articles.save()
    messages.warning(request,"you stopped the work")
    return redirect('l2_edit_file', article_num=a, file_path=f'L2Edit/{a_name}/{a_name}.html')


def l2_edit_update_pause_end(request, pk):
    articles = L2MODEL.L2_Edit.objects.get(id=pk)
    try:
        start_date = timezone.now().strftime('%Y-%m-%d %H:%M:%S')
        articles.start_date = start_date
        a = articles.article_id_id
        a_name = articles.article_id
        articles.filestatus = 's'
        s = 's'
        pause ='p'
        user = request.user
        
        articles.user_name=user
        u_name = User.objects.get(username=user).pk
        file_path = request.POST.get('file_path')
        cursor = connection.cursor()
        l2_start_process_pause= "UPDATE Process_status_process_status SET filestatus='%s' WHERE filestatus ='%s' AND article_id_id='%s' AND activity='L2ED' AND user_name_id='%s';"
        cursor.execute(l2_start_process_pause%(s,pause,a,u_name))

        l2_start_process_pause1= "UPDATE Process_status_production_hours SET end_date='%s', pause_end_date='%s', filestatus='%s' WHERE article_id_id='%s' AND filestatus='p' AND activity='L2ED';"
        cursor.execute(l2_start_process_pause1%(start_date,start_date,s,a))

    except ObjectDoesNotExist:
         return HttpResponse("<h2> current article is not present in database / already moved to next activity </h2>")
    articles.save()
    messages.success(request,"you get started")
    return redirect('l2_edit_file', article_num=a, file_path=f'L2Edit/{a_name}/{a_name}.html')

def l2_update_end(request, pk):
        articles = L2MODEL.L2_Edit.objects.get(id=pk)
        a = articles.article_id
        aa = str(a)
        file_path=f'L2Edit\\{a}\\{a}.html'
#        l2_tex_file=f'L2Edit\\{a}\\{a}.tex'
        typeset = f'Typeset\\{a}\\{a}.html'
        tex_file = f'Typeset\\{a}\\{a}.tex'
#        pdf_file = f'Typeset\\{a}\\{a}.pdf'
        pdf_output_path_folder = 'static/Typeset/'+aa
        latex_file_path = 'static/Typeset/'+aa+'/'+aa+'.tex'
        src_path = os.path.join(settings.STATIC_DIR, file_path)
        dst_path = os.path.join(settings.STATIC_DIR, typeset)

        src_path1 = os.path.join(settings.STATIC_DIR, f'L2Edit\\{a}')
        dst_path1 = os.path.join(settings.STATIC_DIR, f'Typeset\\{a}')
        image_path = dst_path1+'\\media'

        tex_file = os.path.join(settings.STATIC_DIR, tex_file)
#        pdf_file = os.path.join(settings.STATIC_DIR, pdf_file)
        if os.path.exists(dst_path1):
            shutil.rmtree(dst_path1)
#        if os.path.isdir(dst_path1):
#            os.remove(dst_path1)
        shutil.copytree(src_path1, dst_path1)
#        shutil.copy(image_path, dst_path1)
#        shutil.move(dst_path1+'\\media\*.*', dst_path1+'\\') 
#        if os.path.isfile(dst_path):
#            os.remove(dst_path)
        if os.path.exists(image_path):
            for filename in os.listdir(image_path):
                source_file = os.path.join(image_path, filename)
    #            print(source_file)

                # Check if the file is an image (you can extend this condition for other image formats)
                if filename.endswith((".jpg", ".jpeg", ".png", ".gif")):
                    destination_file = os.path.join(dst_path1, filename)
                    print("source_file",source_file)
                    print("destination_file",destination_file)
                    # Copy the image file to the destination folder
                    shutil.copy2(source_file, destination_file)
                    print(f"Copied: {source_file} to {destination_file}")


        with open(src_path, 'r', encoding='utf8') as f:
            file_content = f.read()
#            beatysoup = BeautifulSoup(file_content, 'html.parser')
            beatysoup = BeautifulSoup(file_content, 'html5lib')
            delete_comments = beatysoup.find_all('span', attrs={'data-tracking-deleted': 'true'})
            delete_comments_x = beatysoup.find_all('span', attrs={'class': 'comment-delete-button'})
            del_comments = delete_comments + delete_comments_x
            for span in del_comments:
                span.extract()
#            author_tag = beatysoup.find_all('p', attrs={'author_group'})
            file_content = file_content.replace('mml:','')
        with open(dst_path, 'w', encoding='utf8') as wf:
            content = str(beatysoup)
            content = re.sub(r'<p class="article_title">(.*?)</p>', '<span class="article_title">\\1</span>\n', content)
            content = re.sub(r'<p class="author_group">(.*?)</p>', '\n<span class="author_group">\\1</span>\n', content)
            content = re.sub(r'<p class="affiliation">(.*?)</p>', '<span class="affiliation">\\1</span>\n', content)
            content = re.sub(r'<p class="correspondance">(.*?)</p>', '<span class="correspondance">\\1</span>\n', content)
            content = re.sub(r'<p class="abstract">(.*?)</p>', '<span class="abstract">\\1</span>\n', content)
            content = re.sub(r'<p class="keywords">(.*?)</p>', '<span class="keywords">\\1</span>\n', content)
            content = re.sub(r'<span data-track-id="pending-1-1" data-tracking="true">([^<]*)</span>', '\\1', content, flags=re.DOTALL)
            content = re.sub(r'<span class="fr-tracking-deleted" contenteditable="false" data-tracking-deleted="true">(.*?)</span>', '', content, flags=re.DOTALL)
            content = re.sub(r'<span class="fr-highlight-change" data-track-id="pending-1-2" data-tracking="true"></span>', '', content, flags=re.DOTALL)
            content = re.sub(r'<h([0-9])><span class="fr-highlight-change" data-track-id="pending[-0-9]+" data-tracking="true">(.*?)</span></h', '<h\\1>\\2</h', content, flags=re.DOTALL)
            content = re.sub(r'<span data-track-id="pending[^"]*" data-tracking="true"></span>', '', content, flags=re.DOTALL)
            content = re.sub(r'src="http://127.0.0.1:8000/static/L[1-4]Edit/.*?/media/', 'src="', content, flags=re.DOTALL)
            content = re.sub('<p\s?[^>]*><br></p>', '', content, flags=re.DOTALL)
            content = content.replace('<span class="comments-button">&#x1F4AC;</span>', "")
            content = content.replace('<span class="comment-delete-button" onclick="showConfirmationDialog(this)"> &#x2716;</span>', "")
            content = content.replace('<span class="comment-delete-button" onclick="showConfirmationDialog(this)">&#x2716;</span>', "")
            content = content.replace('<span class="comments-button">💬</span>', "")
            content = content.replace('<span class="comment-delete-button" onclick="showConfirmationDialog(this)"> ✖</span>', "")
            content = content.replace('<span class="comment-delete-button" onclick="showConfirmationDialog(this)">✖</span>', "")
            content = content.replace('<span class="comment">', '<span class="qr">')
            
            print(os.getcwd())
            wf.write(content)
        batch_file_path = 'r.bat'
        commend = ["pandoc", "-s", dst_path, "-o", tex_file, "--lua-filter=html-to-tex.lua", "--template=custom-template.tex"]
        try:
            subprocess.run(commend, check=True)
            print("Conversion successful.")
        except subprocess.CalledProcessError as e:
            print("Conversion failed. Error:", e)
        subprocess.run(['pdflatex', '-quiet', '-output-directory', pdf_output_path_folder, latex_file_path])
#        subprocess.run([batch_file_path, aa], shell=True)


#with open(file_path, 'w', encoding='utf8') as f:        
        file_status = articles.filestatus
        form = l2editForm(request.POST or None, instance=articles)  
        if file_status != 'p':        
            if form.is_valid():
                start_date = timezone.now().strftime('%Y-%m-%d %H:%M:%S')
                articles.end_date = start_date
                form.data._mutable=True
                user = request.user
                articles.user_name = user
                a = articles.article_id_id

                user = request.user
                u_name = User.objects.get(username=user).pk

                u = str(user)
                sta = 'a'
                act1 = 'TYPE'
                st = 'c'
                articles.filestatus = 'c'
                file_status = articles.filestatus
                c = articles.add_comments
                r=articles.add_remarks
                act ='L2ED'
                cursor = connection.cursor()

                try:
                    l2edit_end_update_inuse= "UPDATE Process_status_process_status SET end_date='%s', filestatus='%s'  WHERE  article_id_id='%s' AND activity='%s' AND filestatus = 'i';"
                    cursor.execute(l2edit_end_update_inuse%(start_date,st,a,act))

                    l2edit_end_update_resume= "UPDATE Process_status_process_status SET end_date='%s', filestatus='%s'  WHERE  article_id_id='%s' AND activity='%s' AND filestatus = 's';"
                    cursor.execute(l2edit_end_update_resume%(start_date,st,a,act))

                    l2edit_start_process_end1= "UPDATE Process_status_production_hours SET end_date='%s', filestatus='c'  WHERE  article_id_id='%s' AND filestatus='i' AND activity='L2ED';"
                    cursor.execute(l2edit_start_process_end1%(start_date,a))                    


                    l2edit_user_end_Na = "INSERT INTO Typeset_typeset(filestatus, add_comments, add_remarks, article_id_id) VALUES ('%s','%s','%s','%s');"
                    cursor.execute(l2edit_user_end_Na%(sta, c, r, a))

                    l2edit_user_end_Na_process = "INSERT INTO Process_status_process_status (filestatus,activity,article_id_id) VALUES ('%s','%s','%s');"
                    cursor.execute(l2edit_user_end_Na_process%(sta,act1,a))
            
                except ObjectDoesNotExist:
                    return HttpResponse("<h2> current article is not present in database / already moved to next activity </h2>")

#                shutil.copytree(src_path, dst_path)
                form.save()
                messages.success(request,"sucessfully file was compleated")
                return redirect('l2_process')
        else:
            messages.warning(request,"Please Close your break time")
            return redirect('l2_process')            
        return render(request, 'l2edit/l2_complete_process_update_end.html',{'articles':articles,'form':form})
