class Animal:
    def __init__(self, name):
        self.name = name

    def make_sound(self):
        return "Unknown sound"

class Dog(Animal):
    def make_sound(self):
        return "Bark!"

class Cat(Animal):
    def make_sound(self):
        return "Meow!"

def animal_sounds(self):
    return self.make_sound()

# Creating objects of different classes
dog = Dog()
cat = Cat()
# Using the same function to get different sounds based on the objects' types
print(animal_sounds(dog))  # Output: Bark!
print(animal_sounds(cat))  # Output: Meow!
