function Span(elem)
  if elem.classes:includes('qr') then
    local content = pandoc.utils.stringify(elem.content)
    return pandoc.RawInline('tex', '\\qr{' .. content .. '}')
  end
  if elem.classes:includes('article_title') then
    local content = pandoc.utils.stringify(elem.content)
    return pandoc.RawInline('tex', '\\title{' .. content .. '}')
  end

  if elem.classes:includes('author_group') then
    local content = pandoc.utils.stringify(elem.content)
    local transformed_text = content:gsub(',', '}\\author{')
    return pandoc.RawInline('tex', '\\author{'..transformed_text..'}')
  end
--  if elem.classes:includes('affiliation') then
--    local content = pandoc.utils.stringify(elem.content)
--    return pandoc.RawInline('tex', '\\address{' .. content .. '}')
--  end
  if elem.classes:includes('correspondance') then
    local content = pandoc.utils.stringify(elem.content)
    return pandoc.RawInline('tex', '\\correspondence[]{' .. content .. '}')
  end
  if elem.classes:includes('abstract') then
    local content = pandoc.utils.stringify(elem.content)
    return pandoc.RawInline('tex', '\\abstract{' .. content .. '}')
  end
  if elem.classes:includes('keywords') then
    local content = pandoc.utils.stringify(elem.content)
    return pandoc.RawInline('tex', '\\keywords{' .. content .. '}\n\\maketitle')
  end

  if elem.classes:includes('affiliation') then
    local content = pandoc.utils.stringify(elem.content)
--    local transformed_text = content:gsub('<span>(.-)</span>', '%1')
    local address = content:gsub('%[%[(.-)%]%]', '\\address[%1]{')
    return pandoc.RawInline('tex', address ..'}')
  end

end

--function Span(elem)
--end

-- function P(elem)
--   if elem.classes:includes('article_title') then
--     local content = pandoc.utils.stringify(elem.content)
--     return pandoc.Text('tex', '\\title{' .. content .. '}')
--   end
-- end
-- function P(elem)
--   if elem.classes:includes('article_title') then
--     local content = pandoc.utils.stringify(elem.content)
--     local title = '\\title{' .. content .. '}'
--     return pandoc.RawBlock('tex', title)
--   end
-- end


function Meta(meta)
  -- Check if the 'documentclass' metadata field exists
  if meta["documentclass"] then
    -- Modify the 'documentclass' value as needed
    meta["documentclass"] = pandoc.MetaString("d:/Django/bohr/bhors_tracking/static/New_Layout/cls/Bohr-v2")
  end
  return meta
end




function Pandoc(doc)
  local modified_blocks = {}

  for _, block in ipairs(doc.blocks) do
    if block.t == "Para" then
      local modified_inlines = {}
      
      for _, inline in ipairs(block.content) do
        if inline.t == "Str" then
          local text = inline.text
          local author_match = text:match("(%a+ %a+)%[%[(%d)%]%]") -- Match "Name[[Number]]"
          
          if author_match then
            local name, number = author_match:match("(%a+ %a+)%[(%d)%]")
            local author_output = string.format("\\author[%s]{%s%s}{}", number, name, number)
            table.insert(modified_inlines, pandoc.RawInline("latex", author_output))
          else
            table.insert(modified_inlines, inline)
          end
        else
          table.insert(modified_inlines, inline)
        end
      end

      table.insert(modified_blocks, pandoc.Para(modified_inlines))
    else
      table.insert(modified_blocks, block)
    end
  end

  return pandoc.Pandoc(modified_blocks, doc.meta)
end
