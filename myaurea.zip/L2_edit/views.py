from django.shortcuts import render
from inventory import models as IMODEL
from django.contrib.auth.models import User, Group
from django.db import connection
from django.shortcuts import redirect, render
from django.utils import timezone
import os, re, subprocess, json, shutil
from django.conf import settings
from django.contrib import messages
from django.http import (HttpResponse, HttpResponseBadRequest, HttpResponseForbidden, JsonResponse)
from django.core.exceptions import ObjectDoesNotExist
from .forms import*
from L2_edit import models as L2MODEL
from Typeset import models as TYPEMODEL
from bs4 import BeautifulSoup
#from lxml import etree
import pathlib
from django.http import HttpResponseServerError
from django.contrib.auth.decorators import login_required
from .decorators import group_required
from django.core.mail import send_mail
from django.db.models import Count
from django.views.decorators.csrf import csrf_exempt

@login_required
@group_required(['l2_edit'])

# Create your views here.
def l2_process(request):
    articles = IMODEL.Inventory_Upload.objects.filter(filestatus='a')[:6]
    articles_inuse = L2MODEL.L2_Edit.objects.all()
    articles_count = Inventory_Upload.objects.filter(Q(filestatus='a') | Q(filestatus='i')).annotate(count=Count('id')).order_by('filestatus').count()
    return render(request,'l2edit/l2edit_process.html',{'articles':articles, 'articles_inuse':articles_inuse, 'articles_count':articles_count})


@login_required
@group_required(['l2_edit'])

def l2_start(request,pk):
    articles = IMODEL.Inventory_Upload.objects.get(id=pk)
    a = articles.article_id
    article_id_ID = IMODEL.Inventory_Upload.objects.get(article_id=a).pk
    user = request.user
    u_name = User.objects.get(username=user).pk
    start_date = timezone.now().strftime('%Y-%m-%d %H:%M:%S')
    sta = 'i'
    act ='L2ED'
    articles.user_name=user
    articles.start_date=start_date
    articles.filestatus=sta
    cursor = connection.cursor()

    if L2MODEL.L2_Edit.objects.filter(article_id = article_id_ID).exists():
        messages.warning(request,"Some one Already Started Process Please choise another article ")
        return redirect('l2_process')
        
    else:

        l2_insert_l2 = "INSERT INTO L2_edit_l2_edit (article_id_id, filestatus, start_date, user_name_id) VALUES ('%s','%s','%s','%s');"
        cursor.execute(l2_insert_l2%(article_id_ID,sta,start_date,u_name))

        l2_insert_process = "INSERT INTO Process_status_process_status (article_id_id, filestatus, start_date, activity, user_name_id) VALUES ('%s','%s','%s','%s','%s');"
        cursor.execute(l2_insert_process%(article_id_ID, sta, start_date, act, u_name))
        

        l2_edit_start_process2 = "INSERT INTO Process_status_production_hours (article_id_id, start_date, user_name_id, filestatus, activity) VALUES ('%s','%s','%s','%s','%s');"
        cursor.execute(l2_edit_start_process2%(article_id_ID,start_date,u_name,sta,act))
    articles.save()

    return redirect('l2_edit_file', article_num = article_id_ID, file_path=f'L2Edit/{a}/{a}.html')



@login_required
@group_required(['l2_edit'])

def l2_inuse(request,pk):
    articles = L2MODEL.L2_Edit.objects.get(id=pk)
    a = articles.article_id
    article_id_ID = IMODEL.Inventory_Upload.objects.get(article_id=a).pk
    return redirect('l2_edit_file', article_num = article_id_ID, file_path=f'L2Edit/{a}/{a}.html')

@login_required
@group_required(['l2_edit'])

def l2_edit_file(request, article_num, file_path):
    articles = L2MODEL.L2_Edit.objects.all()
    file_path = os.path.join(settings.STATIC_DIR, file_path)
    file_path = file_path.replace("\\", "/")
    with open(file_path, 'r', encoding='utf8') as f:
        file_content = f.read()
        file_content = file_content.replace('mml:','')
    return render(request, 'L2edit/l2_edit_file.html', {'file_content': file_content, 'article_num':article_num, 'file_path': file_path, 'articles':articles})

@login_required
@group_required(['l2_edit'])

def l2save_file(request, pk):
    file_content = request.POST.get('file_content')
    file_path = request.POST.get('file_path')
    try:
        path = pathlib.Path(file_path)
        with path.open('w', encoding='utf8') as f:
            f.write(file_content)
    except IOError as e:
        print('Exception occurred while saving the file:', e)
        return HttpResponseServerError('Error occurred while saving the file.')

    return redirect('l2_edit_file', article_num=pk, file_path=file_path)


@login_required
@group_required(['l2_edit'])

def l2_update_end(request, pk):
        articles = L2MODEL.L2_Edit.objects.get(id=pk)
        a = articles.article_id
        file_path=f'L2Edit/{a}'
        l2edit = f'author_review/{a}'
        src_path = os.path.join(settings.STATIC_DIR, file_path)
        dst_path = os.path.join(settings.STATIC_DIR, l2edit)

        form = l2editForm(request.POST or None, instance=articles)
        file_status = articles.filestatus

        if file_status != 'p':        
            if form.is_valid():
                start_date = timezone.now().strftime('%Y-%m-%d %H:%M:%S')
                articles.end_date = start_date
                form.data._mutable=True
                user = request.user
                articles.user_name = user
                a = articles.article_id_id
                aa = articles.article_id

                print('aa', aa)
                user = request.user
                u_name = User.objects.get(username=user).pk
                u = str(user)
                sta = 'a'
                act1 = 'AURW'
                file_status = articles.filestatus
                articles.filestatus = 'c'
                c = articles.add_comments
                r=articles.add_remarks
                act ='L2ED'
                cursor = connection.cursor()
                
                try:                
                    l2_update_inventry= "UPDATE inventory_inventory_upload SET filestatus='c' WHERE article_id='%s';"
                    cursor.execute(l2_update_inventry%(aa))


                    l2edit_end_update_inuse= "UPDATE Process_status_process_status SET end_date='%s',filestatus='c'  WHERE  article_id_id='%s' AND activity='%s' AND filestatus = 'i';"
                    cursor.execute(l2edit_end_update_inuse%(start_date,a,act))

                    l2edit_end_update_resume= "UPDATE Process_status_process_status SET end_date='%s',filestatus='c'  WHERE  article_id_id='%s' AND activity='%s' AND filestatus = 's';"
                    cursor.execute(l2edit_end_update_resume%(start_date,a,act))

                    l2edit_start_process_end1= "UPDATE Process_status_production_hours SET end_date='%s', filestatus='c'  WHERE  article_id_id='%s' AND filestatus='i' AND activity='L2ED';"
                    cursor.execute(l2edit_start_process_end1%(start_date,a))                    

                    l2edit_user_end_Na = "INSERT INTO author_review_Author_review(filestatus, add_comments, add_remarks, article_id_id) VALUES ('%s','%s','%s','%s');"
                    cursor.execute(l2edit_user_end_Na%(sta, c, r, a))

                    l2edit_user_end_Na_process = "INSERT INTO Process_status_process_status (filestatus,activity,article_id_id) VALUES ('%s','%s','%s');"
                    cursor.execute(l2edit_user_end_Na_process%(sta,act1,a))

                except ObjectDoesNotExist:
                    return HttpResponse("<h2> current article is not present in database / already moved to next activity </h2>")

                shutil.copytree(src_path, dst_path)                
                form.save()
                messages.success(request,"sucessfully file was compleated")
                inventory_obj = IMODEL.Inventory_Upload.objects.get(article_id=articles.article_id)
                correspondance_email = inventory_obj.correspondance_email

            # Send email to the correspondance_email
                send_email_alert(articles.article_id, correspondance_email)
                return redirect('l2_process')                
        else:
            messages.warning(request,"Please Close your break time")
            return redirect('l2_process')
            
        return render(request, 'l2edit/l2_complete_process_update_end.html',{'articles':articles,'form':form})

def send_email_alert(article_id, recipient_email):
    subject = f"Article {article_id} Completed - Action Required"
    message = f"Dear [Recipient Name],\n\nArticle {article_id} has been completed and is now available for author review.\n\nPlease visit the author review page to review and provide feedback.\n\nThank you,\nThe Copyedit Team"
    from_email = settings.EMAIL_HOST_USER
    recipient_list = [recipient_email]
    send_mail(subject, message, from_email, recipient_list, fail_silently=False)

def upload_image(request):
    if request.method == 'POST' and request.FILES.get('file'):
        uploaded_file = request.FILES['file']
#        print(uploaded_file) ---> image2.jpg
#        file_path = os.path.join(settings.STATIC_DIR, uploaded_file)
#        file_path = file_path.replace("\\", "/")
#        print(file_path)
        file_path = os.path.join(settings.MEDIA_ROOT, 'uploads', uploaded_file.name)
        print(file_path)
        with open(file_path, 'wb') as destination:
            for chunk in uploaded_file.chunks():
                destination.write(chunk)
#http://127.0.0.1:8000/static/L2Edit/fncel-2021-1082181/media/image2.jpg
        image_url = '/static/media/uploads/'+uploaded_file.name
        print(image_url)
#        form = ImageUploadForm(request.POST, request.FILES)
#        image_url = '/uploads/' + uploaded_file.name
        return JsonResponse({'link': image_url, 'file': {'url': image_url,}})
    else:
        return JsonResponse({'error': 'Invalid request'}, status=400)