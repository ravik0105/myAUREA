from bs4 import BeautifulSoup
import re
import subprocess
from lxml import etree
src_path = 'd:\\Django\\bohr\\bhors_tracking\\static\\L2Edit\\bkp\\fncel-2021-1082181\\fncel-2021-1082181.xhtml'
dst_path = 'd:\\Django\\bohr\\bhors_tracking\\static\\L2Edit\\fncel-2020-1080021\\fncel-2021-1082181-out.xhtml'
#src_path = 'd:\\Django\\bohr\\bhors_tracking\\static\\L2Edit\\fncel-2020-1080021\\fncel-2020-1080021.xhtml'
#dst_path = 'd:\\Django\\bohr\\bhors_tracking\\static\\L2Edit\\fncel-2020-1080021\\fncel-2020-1080021-out.xhtml'
with open(src_path, 'r', encoding='utf8') as f:
    file_content = f.read()
    beatysoup = BeautifulSoup(file_content, 'html5lib')
    delete_comments = beatysoup.find_all('span', attrs={'data-tracking-deleted': 'true'})
#    print(delete_comments)
    for span in delete_comments:
        span.extract()

    author_tag = beatysoup.find_all('p', attrs={'author_group'})
#    content = str(author_tag.contents)
#    authors = content.split(', ')
    author_tags = []
    for a in author_tag:
        a = str(a)
        authors = a.split(', ')
        #authors = str(authors)
        for a in authors:
            a = a.replace('<p class="author_group">','')
            a = a.replace('</p>','')
            a = re.sub('^(.*?)<sup>([^>]*)</sup>$','<span class="author"><sup>\\2</sup>\\1</span>', a)
            author_tags = append(a)
        print(author_tags)
#        number = authors.split('<sup>', 1)[1].split('</sup>', 1)[0]
#        name = authors.split('<sup>', 1)[1].split('</sup>', 1)[1]
#        author_output = f'<span class="author"><sup>{number}</sup>{name}</span>'
#    print(author_output)
with open(dst_path, 'w', encoding='utf8') as wf:
    content = str(beatysoup)

#    print(content)
    #content = content.replace('<span data-track-id="pending[^"]*" data-tracking="true"></span>', "")
    #content = content.replace('<span data-track-id="pending[^"]*" data-tracking="true"></span>', "")
#    content = re.sub(r'<sup>(.*?)</sup>', '[\\1]', content)
#    print(output)
    content = re.sub(r'<p class="article_title">(.*?)</p>', '<span class="article_title">\\1</span>', content)
    content = re.sub(r'<p class="author_group">(.*?)</p>', '<span class="author_group">\\1</span>', content)
    content = re.sub(r'<p class="affiliation">(.*?)</p>', '<span class="affiliation">\\1</span>', content)
    content = re.sub(r'<p class="correspondance">(.*?)</p>', '<span class="correspondance">\\1</span>', content)
    content = re.sub(r'<p class="abstract">(.*?)</p>', '<span class="abstract">\\1</span>', content)
    content = re.sub(r'<p class="keywords">(.*?)</p>', '<span class="keywords">\\1</span>', content)
    content = re.sub(r'<span data-track-id="pending[^"]*" data-tracking="true"></span>', '', content, flags=re.DOTALL)
    content = re.sub(r'<span data-track-id="pending-1-1" data-tracking="true">([^<]*)</span>', '\\1', content, flags=re.DOTALL)
    content = content.replace('<span class="comments-button">&#x1F4AC;</span>', "")
#    content = content.replace('<sup>', "[[")
#    content = content.replace('</sup>', "]]")
    content = content.replace('<span class="comment-delete-button" onclick="showConfirmationDialog(this)"> &#x2716;</span>', "")
    content = content.replace('<span class="comment-delete-button" onclick="showConfirmationDialog(this)">&#x2716;</span>', "")
    content = content.replace('<span class="comments-button">💬</span>', "")
    content = content.replace('<span class="comment-delete-button" onclick="showConfirmationDialog(this)"> ✖</span>', "")
    content = content.replace('<span class="comment-delete-button" onclick="showConfirmationDialog(this)">✖</span>', "")
    content = content.replace('<span class="comment">', '<span class="qr">')
    
    #     #content = re.sub('<span\s+data-track-id="pending-1-1"\s+data-tracking="true">(.*?)</span>', '\1', content, flags=re.DOTALL)
#    content =
#    re.sub(r'<span[^>]*data-tracking-deleted="true"[^>]*>.*?</span>', '\1', file_content, flags=re.DOTALL)
    wf.write(content)

#parser = etree.XMLParser(dtd_validation=True)  # Enable DTD validation
#try:
#    tree = etree.fromstring(content.encode("utf-8"), parser)
#    print("Validation successful: The XHTML is well-formed.")
#except etree.XMLSyntaxError as e:
#    print(f"Validation failed: {e}")
    
#commend = ["pandoc", "-s", "d:/Django/bohr/bhors_tracking/static/L2Edit/fncel-2020-1080021/fncel-2020-1080021-out.xhtml", "-o", "d:/Django/bohr/bhors_tracking/static/L2Edit/fncel-2020-1080021/fncel-2020-1080021.tex", "--lua-filter=html-to-tex.lua", "--template=custom-template.tex"]
commend = ["pandoc", "-s", "d:/Django/bohr/bhors_tracking/static/L2Edit/fncel-2020-1080021/fncel-2021-1082181-out.xhtml", "-o", "d:/Django/bohr/bhors_tracking/static/L2Edit/fncel-2020-1080021/fncel-2021-1082181.tex", "--lua-filter=html-to-tex.lua", "--template=custom-template.tex"]

try:
    subprocess.run(commend, check=True)
    print("Conversion successful.")
except subprocess.CalledProcessError as e:
    print("Conversion failed. Error:", e)
