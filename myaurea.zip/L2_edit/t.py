input_html = """
<p class="author_group">Prethi Mallick<sup>1</sup>, Sanchari Chakraborty<sup>2</sup>, Randrita Pal<sup>3</sup>, Ankita Samaddar<sup>4</sup>, Sudip Kumar Saha<sup>5</sup></p>
"""

# Extract the content within the <p> element using string manipulation
start_index = input_html.index('>')
end_index = input_html.rindex('</p>')
author_group_content = input_html[start_index + 1: end_index]

# Split the content into individual authors
authors = [author.strip() for author in author_group_content.split(',')]

# Generate the desired LaTeX output
output = ""
for author in authors:
    author_output = f'<span class="author">{author}</span>'
    output += author_output

print(output)
