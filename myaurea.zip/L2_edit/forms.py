from collections import UserList
from email.policy import default
from faulthandler import disable
from django import forms
from django.contrib.auth.models import User
from .models import *
from django.contrib.admin.widgets import AdminDateWidget, AdminTimeWidget, AdminSplitDateTime

from django.contrib.admin import widgets


class ImageUploadForm(forms.Form):
    image_upload = forms.FileField()


class l2editForm(forms.ModelForm):
    #article_id = forms.CharField(disabled=True)
    class Meta:
        model=L2_Edit
        fields=['add_remarks', 'add_comments']
        widgets = {
        "start_date":  AdminDateWidget(),
        "start_time":  AdminTimeWidget(),
        "end_date":  AdminDateWidget(),
        "end_time":  AdminTimeWidget(),
        }
