from django.contrib import admin
from . import views
from . views import*
from django.views.i18n import JavaScriptCatalog
from django.urls import path
from django.core.exceptions import *
#from django.conf.urls import url

urlpatterns = [
    path('l2_process/', views.l2_process, name='l2_process'),
    path('l2_start/<int:pk>', views.l2_start, name='l2_start'),
    path('l2_inuse/<int:pk>', views.l2_inuse, name='l2_inuse'),
    path('edit/<int:article_num>/<path:file_path>/', l2_edit_file, name='l2_edit_file'),
    path('save/<int:pk>', l2save_file, name='l2save_file'),    
    path('l2_update_end/<int:pk>', views.l2_update_end, name="l2_update_end"),
    path('upload-image/', upload_image, name='upload_image'),
#    url(r'^upload_image_validation', views.upload_image_validation, name='upload_image_validation'),    
#    url(r'^upload_image$', views.upload_image, name='upload_image'),
]