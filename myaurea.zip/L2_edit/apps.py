from django.apps import AppConfig


class L2EditConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'L2_edit'
