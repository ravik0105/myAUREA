function Span(elem)
  if elem.classes:includes('qr') then
    local content = pandoc.utils.stringify(elem.content)
    return pandoc.RawInline('tex', '\\qr{' .. content .. '}')
  end
  if elem.classes:includes('comment') then
    local content = pandoc.utils.stringify(elem.content)
    return pandoc.RawInline('tex', '\\qr{' .. content .. '}')
  end
  if elem.classes:includes('article_title') then
    local content = pandoc.utils.stringify(elem.content)
    return pandoc.RawInline('tex', '\\title{' .. content .. '}')
  end

  if elem.classes:includes('author_group') then
    local content = pandoc.utils.stringify(elem.content)
    return pandoc.RawInline('tex', '\\author{' .. content .. '}{}')
  end
  if elem.classes:includes('correspondance') then
    local content = pandoc.utils.stringify(elem.content)
    return pandoc.RawInline('tex', '\\correspondence[1]{' .. content .. '}')
  end
  if elem.classes:includes('abstract') then
    local content = pandoc.utils.stringify(elem.content)
    return pandoc.RawInline('tex', '\\abstract{' .. content .. '}')
  end
  if elem.classes:includes('keywords') then
    local content = pandoc.utils.stringify(elem.content)
    return pandoc.RawInline('tex', '\\keywords{' .. content .. '}\n\\maketitle')
  end

  if elem.classes:includes('keywords') then
    local content = pandoc.utils.stringify(elem.content)
    return pandoc.RawInline('tex', '\\keywords{' .. content .. '}\n\\maketitle')
  end


  if elem.classes:includes('affiliation') then
    local content = pandoc.utils.stringify(elem.content)
    return pandoc.RawInline('tex', '\\address{' .. content .. '}\n')
  end

end

function RawInline(elem)
  if string.match(elem.text, '\\texorpdfstring{{}{(.-)}}') then
    local section_title = string.match(elem.text, '\\texorpdfstring{{}{(.-)}}')
    return pandoc.RawInline('latex', '')
  end
end

function Header(elem)
  -- Map heading levels to LaTeX sectioning commands
  local sectioning_commands = {
    [1] = "\\section",
    [2] = "\\subsection",
    [3] = "\\subsubsection",
    [4] = "\\paragraph",
    [5] = "\\subparagraph"
  }

  -- Replace headers with the corresponding \section, \subsection, etc.
  if elem.level <= #sectioning_commands then
    local level = elem.level
    local content = pandoc.utils.stringify(elem.content)
    local sectioning_command = sectioning_commands[level] or "\\section"
    return pandoc.RawBlock('tex', sectioning_command .. '{' .. content .. '}')
  end

  return elem
end
