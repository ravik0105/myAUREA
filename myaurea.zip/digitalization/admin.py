from django.contrib import admin
from .models import digitalization

class digital_edit_admin (admin.ModelAdmin):
    list_dispaly = ['article_id','rec_date', 'filestatus']
    def rec_date(self, obj):
        return obj.article_id.received_date if obj.article_id else None

# admin.site.register(digitalization, digital_edit_admin)        
# Register your models here.
