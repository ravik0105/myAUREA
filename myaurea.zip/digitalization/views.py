from django.shortcuts import render, redirect
import lxml.etree as ET  # For XML processing
import os
#from ebooklib import epub
from digitalization import models as DIGITMODEL
from inventory import models as IMODEL
from django.contrib.auth.models import User, Group
from django.utils.timezone import datetime
from django.utils import timezone
from django.db import connection
from django.contrib import messages
from django.http import (HttpResponse, HttpResponseBadRequest, HttpResponseForbidden)
from django.db.models import Count
from django.db.models import Q
from django.contrib.auth.decorators import login_required
from .decorators import group_required




@login_required
@group_required(['Digitalization'])

def digital_process(request):
    articles = DIGITMODEL.digitalization.objects.filter(filestatus = 'a')[:3]
    articles_inuse = DIGITMODEL.digitalization.objects.filter(filestatus='i')  
    articles_count = DIGITMODEL.digitalization.objects.filter(Q(filestatus='a') | Q(filestatus='i')).annotate(count=Count('id')).order_by('filestatus').count()
    return render(request,'digital_edit_process.html',{'articles':articles, 'articles_inuse':articles_inuse, 'articles_count':articles_count})


def digital_start(request,pk):
    articles = DIGITMODEL.digitalization.objects.get(id=pk)
    a = articles.article_id
    aa = articles.id
    article_id_ID = IMODEL.Inventory_Upload.objects.get(article_id=a).pk
    article_title = IMODEL.Inventory_Upload.objects.get(article_id=a).title
    article_author = IMODEL.Inventory_Upload.objects.get(article_id=a).authors
#    print("This are articles by ravi:",articles)
    user = request.user
    u_name = User.objects.get(username=user).pk
    start_date = timezone.now().strftime('%Y-%m-%d %H:%M:%S')
    sta = 'i'
    act ='DIG'
    articles.user_name=user
    articles.start_date=start_date
    articles.filestatus=sta
    cursor = connection.cursor()

#    if DIGITMODEL.digitalization.objects.filter(article_id = article_id_ID).exists():
#        messages.warning(request,"Some one Already Started Process Please choise another article ")
#        return redirect('digital_process')
    digital_update_process= "UPDATE Process_status_process_status SET start_date='%s', filestatus='i', user_name_id='%s' WHERE article_id_id='%s' and activity='%s';"
    cursor.execute(digital_update_process%(start_date, u_name, article_id_ID, act))

    Digital_Completion_start_process = "INSERT INTO Process_status_production_hours (article_id_id,start_date,user_name_id,filestatus,activity) VALUES ('%s','%s','%s','%s','%s');"
    cursor.execute(Digital_Completion_start_process%(article_id_ID,start_date,u_name,sta,act))
    articles.save()

#    return redirect('digit_thumpnail', article_num = article_id_ID)
    return render(request,'ebooks_files.html',{'aa':aa, 'articles':articles, 'article_num': article_id_ID, 'article_title':article_title, 'article_author':article_author})

"""
def display_xml_and_html(request):
    # Load your XML data
    xml_data = ET.parse("static/Digitalization/fncel-2021-1082181/postpre.xml")

    xml_string = ET.tostring(xml_data, pretty_print=True, encoding="utf-8").decode("utf-8")

    
    # Load your XSL stylesheet
    xsl_stylesheet = ET.parse("static/Digitalization/fncel-2021-1082181/journal_ViewIMF-v1.0.xsl")

    # Apply XSL transformation to the XML data
    transform = ET.XSLT(xsl_stylesheet)
    html_output = transform(xml_data)

    context = {
        "xml_data": xml_string,
        "html_output": html_output,
    }

    return render(request, "display_xml_and_html.html", context)
"""
def view_epub(request, epub_id):
    articles = DIGITMODEL.digitalization.objects.get(id=epub_id)
#    articles = L2MODEL.L2_Edit.objects.get(id=pk)
    epub_path = "static/Digitalization/"+str(articles)+"/"+str(articles)+".epub"
    with open(epub_path, "rb") as epub_file:
        response = HttpResponse(epub_file.read(), content_type="application/epub+zip")
        response["Content-Disposition"] = f"inline; filename={os.path.basename(epub_path)}"
        return response
        
def view_xml(request, epub_id):
    articles = DIGITMODEL.digitalization.objects.get(id=epub_id)
    aa = articles.id
    # Load your XML data
    xml_data = ET.parse("static/Digitalization/"+str(articles)+"/"+str(articles)+".xml")

    xml_string = ET.tostring(xml_data, pretty_print=True, encoding="utf-8").decode("utf-8")

    
    # Load your XSL stylesheet
    xsl_stylesheet = ET.parse("static/css/journal_ViewIMF-v1.0.xsl")

    # Apply XSL transformation to the XML data
    transform = ET.XSLT(xsl_stylesheet)
    html_output = transform(xml_data)

    context = {
        "xml_data": xml_string,
        "html_output": html_output,
        "aa":aa
    }

    return render(request, "display_xml_and_html.html", context)
from django.http import JsonResponse

def update_xml_data(request, epub_id):
    articles = DIGITMODEL.digitalization.objects.get(id=epub_id)
    if request.method == 'POST':
        try:
            xml_data = request.body.decode('utf-8')
            xml_file_path = 'static/Digitalization/'+str(articles)+'/'+str(articles)+'.xml'
            with open(xml_file_path, 'w', encoding='utf-8') as xml_file:
                xml_file.write(xml_data)
            return JsonResponse({'status': 'success', 'message': 'XML data saved successfully'})
        except Exception as e:
            return JsonResponse({'status': 'error', 'message': str(e)})
    else:
        return JsonResponse({'status': 'error', 'message': 'Invalid request method'})


def update_html_data(request, epub_id):
    articles = DIGITMODEL.digitalization.objects.get(id=epub_id)
    if request.method == 'POST':
        try:
            xml_data = request.body.decode('utf-8')
            xml_file_path = 'static/Digitalization/'+str(articles)+'/'+str(articles)+'.html'
            with open(xml_file_path, 'w', encoding='utf-8') as xml_file:
                xml_file.write(xml_data)
            return JsonResponse({'status': 'success', 'message': 'HTML data saved successfully'})
        except Exception as e:
            return JsonResponse({'status': 'error', 'message': str(e)})
    else:
        return JsonResponse({'status': 'error', 'message': 'Invalid request method'})

        
def view_html(request, epub_id):
    articles = DIGITMODEL.digitalization.objects.get(id=epub_id)
    aa = articles.id
    # Load your XML data
    html_data = ET.parse("static/Digitalization/"+str(articles)+"/"+str(articles)+".html")

    html_string = ET.tostring(html_data, pretty_print=True, encoding="utf-8").decode("utf-8")

    
    # Load your XSL stylesheet
#    xsl_stylesheet = ET.parse("static/css/journal_ViewIMF-v1.0.xsl")

    # Apply XSL transformation to the XML data
#    transform = ET.XSLT(xsl_stylesheet)
#    html_output = transform(xml_data)

    context = {
        "html_data": html_string,
#        "html_output": html_output,
        "aa":aa
    }

    return render(request, "htmlview.html", context)


def view_idml(request, epub_id):
    articles = DIGITMODEL.digitalization.objects.get(id=epub_id)
    aa = articles.id
    # Load your XML data
    html_data = ET.parse("static/Digitalization/"+str(articles)+"/"+str(articles)+".idml")

    html_string = ET.tostring(html_data, pretty_print=True, encoding="utf-8").decode("utf-8")

    
    # Load your XSL stylesheet
#    xsl_stylesheet = ET.parse("static/css/journal_ViewIMF-v1.0.xsl")

    # Apply XSL transformation to the XML data
#    transform = ET.XSLT(xsl_stylesheet)
#    html_output = transform(xml_data)

    context = {
        "html_data": html_string,
#        "html_output": html_output,
        "aa":aa
    }

    return render(request, "indesignview.html", context)
    