from functools import wraps
from django.shortcuts import redirect
from django.http import HttpResponseForbidden


def group_required(required_group_names):
    def decorator(view_func):
        @wraps(view_func)
        def wrapper(request, *args, **kwargs):
            if not request.user.is_authenticated:
                return redirect('login')

            if request.user.is_superuser:
                # Superusers have access to everything
                return view_func(request, *args, **kwargs)

            if not request.user.groups.filter(name__in=required_group_names).exists():
                return HttpResponseForbidden('You do not have permission to access this page.')

            return view_func(request, *args, **kwargs)
        return wrapper
    return decorator
