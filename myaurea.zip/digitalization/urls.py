from django.urls import path
from . import views

urlpatterns = [
path('digital_process/', views.digital_process, name='digital_process'),
path('digital_start/<int:pk>', views.digital_start, name='digital_start'),
#path('digital_inuse/<int:pk>', views.digital_inuse, name='digital_inuse'),
#path('display-xml-and-html/', views.display_xml_and_html, name='display_xml_and_html'),
path('update-xml-data/<int:epub_id>', views.update_xml_data, name='update-xml-data'),
path('update-html-data/<int:epub_id>', views.update_html_data, name='update-html-data'),
path('view-epub/<int:epub_id>', views.view_epub, name='view_epub'),
path('view-html/<int:epub_id>', views.view_html, name='view_html'),
path('view-xml/<int:epub_id>', views.view_xml, name='view_xml'),
path('view_idml/<int:epub_id>', views.view_idml, name='view_idml'),
]