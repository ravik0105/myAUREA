from django.shortcuts import render
from inventory import models as IMODEL
#from Typeset import models as TS
from django.contrib.auth.models import User
from django.db import connection
from django.shortcuts import redirect, render
from django.utils import timezone
import os, subprocess, shutil, re
from django.conf import settings
from Typeset import models as TYPEMODEL
from django.contrib import messages
from django.http import HttpResponse
from django.core.exceptions import ObjectDoesNotExist
from .forms import*
# Create your views here.
#from Typeset import models as TYPEMODEL
from django.template.loader import render_to_string
from django.contrib.auth.decorators import login_required
from .decorators import group_required
from django.db.models import Count
from django.middleware.csrf import get_token



@login_required
@group_required(['Typesetting'])
def typeset_process(request):
    articles = TYPEMODEL.Typeset.objects.all()
    articles_inuse = TYPEMODEL.Typeset.objects.filter(filestatus='i')  
    articles_count = TYPEMODEL.Typeset.objects.filter(Q(filestatus='a') | Q(filestatus='i')).annotate(count=Count('id')).order_by('filestatus').count()
    return render(request,'typeset/typeset_process.html',{'articles':articles,  'articles_count':articles_count, 'articles_inuse':articles_inuse})



@login_required
@group_required(['Typesetting'])
def typeset_start(request,pk):
    articles = TYPEMODEL.Typeset.objects.get(id=pk)
    a = articles.article_id
    article_id_ID = IMODEL.Inventory_Upload.objects.get(article_id=a).pk
#    print("This are articles by ravi:",articles)
    user = request.user
    u_name = User.objects.get(username=user).pk
    start_date = timezone.now().strftime('%Y-%m-%d %H:%M:%S')
    sta = 'i'
    act ='TYPE'
    articles.user_name=user
    articles.start_date=start_date
    articles.filestatus=sta
    cursor = connection.cursor()
    already_process = 1
    if already_process == 0:
        messages.warning(request,"Some one Already Started Process Please choise another article ")
        return redirect('typeset_process')
    else:
        l2_update_process= "UPDATE Process_status_process_status SET start_date='%s', filestatus='i', user_name_id='%s' WHERE article_id_id='%s' and activity='%s';"
        cursor.execute(l2_update_process%(start_date, u_name, article_id_ID, act))

        Copy_Edit_Completion_start_process1 = "INSERT INTO Process_status_production_hours (article_id_id,start_date,user_name_id,filestatus,activity) VALUES ('%s','%s','%s','%s','%s');"
        cursor.execute(Copy_Edit_Completion_start_process1%(article_id_ID,start_date,u_name,sta,act))
    articles.save()

    return redirect('latex_editor', article_num = article_id_ID)


@login_required
@group_required(['Typesetting'])
def latex_editor(request, article_num):
    print("rrrrrrrrrr",article_num)
    overal_articles = TYPEMODEL.Typeset.objects.all()
    articles = TYPEMODEL.Typeset.objects.get(article_id_id=article_num)
#    print("aaaaaaaaaaaaa",articles)
    a = str(articles)
    article_id_ID = IMODEL.Inventory_Upload.objects.get(article_id=a).pk
#    const engine = new PdfTeXEngine();
#    await engine.loadEngine();
    Latex_error = False
    latex_err_log_content = ""
#    path = path
    html_file_path = 'static/Typeset/'+a+'/'+a+'.html'
    latex_file_path = 'static/Typeset/'+a+'/'+a+'.tex'
    xml_file_path = 'static/Typeset/'+a+'/'+a+'.xml'
    latex_log_file_path = 'static/Typeset/'+a+'/'+a+'.log'
    pdf_output_path_folder = 'static/Typeset/'+a
    pdf_output_path = 'static/Typeset/'+a+'/'+a+'.pdf'
#    print('xxxxxxxxxxxxxxxxx',html_file_path)
#    log_file_path = latex_log_file_path
    #error_entries = parse_log_file(log_file_path)


    if request.method == 'POST':
        latex_content = request.POST.get('xml_content')
        latex_content = '\n'.join(line.strip() for line in latex_content.split('\n'))

        # Update the LaTeX file with the modified content
        with open(xml_file_path, 'w', encoding="utf8") as f:
            latex_content = latex_content.replace('<?xml version="1.0"?>','<?xml version="1.0" encoding="UTF-8" standalone="no"?><!DOCTYPE article PUBLIC "-//NLM//DTD Journal Publishing DTD v2.3 20070202//EN" "journalpublishing.dtd">')
            latex_content = latex_content.replace('<article>',f'<article xmlns:mml="http://www.w3.org/1998/Math/MathML" xmlns:xlink="http://www.w3.org/1999/xlink" article-type="research-article">')
            latex_content = latex_content.replace('<history/>','<history><date date-type="received"><day>XX</day><month>XX</month><year>XXXX</year></date></history>')

            latex_content = latex_content.replace('&lt;ref-list&gt;','<ref-list>')
            latex_content = latex_content.replace('&lt;/ref-list&gt;','</ref-list>')

            latex_content = re.sub(r'&lt;ref&gt;([\d+])\.?','<ref id="B\\1"><citation citation-type="journal">', latex_content)
            latex_content = latex_content.replace('&lt;/ref&gt;','</citation></ref>')

            latex_content = latex_content.replace('&lt;authors&lt;','<person-group person-group-type="author">')
            latex_content = latex_content.replace('&lt;/authors&lt;','</person-group>')
            
            latex_content = latex_content.replace('&lt;auth&lt;','<name>')
            latex_content = latex_content.replace('&lt;/auth&lt;','</name>')

            latex_content = latex_content.replace('&lt;fname&lt;','<surname>')
            latex_content = latex_content.replace('&lt;/fname&lt;','</surname>')

            latex_content = latex_content.replace('&lt;lname&lt;','<given-names>')
            latex_content = latex_content.replace('&lt;/lname&lt;','</given-names>')

            latex_content = latex_content.replace('&lt;article_title&lt;','<article-title>')
            latex_content = latex_content.replace('&lt;/article_title&lt;','</article-title>')

            latex_content = latex_content.replace('&lt;em&lt;&lt;journal_title&lt;','<source><italic>')
            latex_content = latex_content.replace('&lt;/journal_title&lt;&lt;/em&lt;','</italic></source>')

            latex_content = latex_content.replace('&lt;year&lt;','<year>')
            latex_content = latex_content.replace('&lt;/year&lt;','</year>')
            
            latex_content = latex_content.replace('&lt;volume&lt;','<volume>')
            latex_content = latex_content.replace('&lt;/volume&lt;','</volume>')

            latex_content = latex_content.replace('&lt;issue&lt;','<issue>')
            latex_content = latex_content.replace('&lt;/issue&lt;','</issue>')

            latex_content = latex_content.replace('&lt;pg_rng&lt;','<fpage>')
            latex_content = latex_content.replace('&lt;/pg_rng&lt;','</fpage>')
            
            latex_content = latex_content.replace('&lt;doi&lt;','<doi>')
            latex_content = latex_content.replace('&lt;/doi&lt;','</doi>')

            latex_content = latex_content.replace('&lt;pmid&lt;','<pmid>')
            latex_content = latex_content.replace('&lt;/pmid&lt;','</pmid>')

            latex_content = latex_content.replace('xmlns:m="http://www.w3.org/1998/Math/MathML"','xmlns:mml="http://www.w3.org/1998/Math/MathML"')
            latex_content = latex_content.replace('<dy>XX</day>','')
            latex_content = latex_content.replace('<month>XX</month>','')
            
            latex_content = latex_content.replace('<m:','<mml:')
            latex_content = latex_content.replace('</m:','</mml:')

            latex_content = latex_content.replace('<inline-formula','<disp-formula')
            latex_content = latex_content.replace('</inline-formula','</disp-formula')
            latex_content = latex_content.replace('<article article-type="research-article">','<article xmlns:mml="http://www.w3.org/1998/Math/MathML" xmlns:xlink="http://www.w3.org/1999/xlink" article-type="research-article">')
            latex_content = re.sub(r'<p[^>]*><ref-list>','<ref-list>', latex_content)
            latex_content = latex_content.replace('</ref-list></p>','</ref-list>')
            f.write(latex_content)

        # Regenerate the PDF output
        try:
            subprocess.run(['pdflatex', '-quiet', '-output-directory', pdf_output_path_folder, latex_file_path])
#            subprocess.run(['pandoc', '--pdf-engine=lualatex', latex_file_path, '-o', pdf_output_path])
        except subprocess.CalledProcessError as e:
            print(f"Error executing pdflatex command: {e}")
            # Handle the error, log it, or return an appropriate response
#        subprocess.run(['pdflatex', '-output-directory', 'static/Typeset/fncel-2020-1080021', latex_file_path])

    # Read the LaTeX file
    with open(xml_file_path, 'r', encoding="utf8") as f:
        xml_content = f.read().strip()
    try:
        with open(latex_log_file_path, 'r', encoding="utf8", errors='ignore') as f:
            latex_err_log_content = f.read().strip()
    except FileNotFoundError:
        with open(latex_log_file_path, 'w', encoding="utf8", errors='ignore') as f:
            pass

    # Render the template with the LaTeX content and PDF output path
    csrf_token = get_token(request)
    context = {
        'xml_content': xml_content,
        'pdf_output_path': pdf_output_path,
        'Latex_error': Latex_error,
        'latex_err_log_content': latex_err_log_content,
        'overal_articles': overal_articles,
        'article_num': article_num
#        'csrf_token': csrf_token,
    }
    #html = render_to_string('typeset/typeset_edit_file.html', context)
    return render(request, 'typeset/typeset_edit_file.html', context)
    #return HttpResponse(html)



@login_required
@group_required(['Typesetting'])
def typeset_edit_update_pause_start(request, pk):
    try:
        articles = TYPEMODEL.Typeset.objects.get(id=pk)
        a = articles.article_id_id
        a_name = articles.article_id
        articles.filestatus = 'p'
        s = 'p'
        user = request.user
        
        articles.user_name=user
        u_name = User.objects.get(username=user).pk
        start_date = timezone.now().strftime('%Y-%m-%d %H:%M:%S')
        articles.start_date = start_date
        act = 'TYPE'
        inuse = 'i'        
        cursor = connection.cursor()
        type_start_process_pause= "UPDATE Process_status_process_status SET filestatus='%s' WHERE article_id_id ='%s' AND activity='TYPE' AND user_name_id ='%s' AND filestatus ='%s';"
        cursor.execute(type_start_process_pause%(s,a,u_name,inuse))

        type_start_process_pause1 = "INSERT INTO Process_status_production_hours (article_id_id,start_date,pause_date,user_name_id,filestatus,activity) VALUES ('%s','%s','%s','%s','%s','%s');"
        cursor.execute(type_start_process_pause1%(a,start_date,start_date,u_name,s,act))
    except ObjectDoesNotExist:
         return HttpResponse("<h2> current article is not present in database / already moved to next activity </h2>")
    articles.save()
    messages.warning(request,"you stopped the work")
    return redirect('latex_editor', article_num=a)



@login_required
@group_required(['Typesetting'])
def typeset_edit_update_pause_end(request, pk):
    articles = TYPEMODEL.Typeset.objects.get(id=pk)
    try:
        start_date = timezone.now().strftime('%Y-%m-%d %H:%M:%S')
        articles.start_date = start_date
        a = articles.article_id_id
        a_name = articles.article_id
        articles.filestatus = 's'
        s = 's'
        pause ='p'
        user = request.user
        
        articles.user_name=user
        u_name = User.objects.get(username=user).pk
#        file_path = request.POST.get('file_path')
        cursor = connection.cursor()
        type_start_process_pause= "UPDATE Process_status_process_status SET filestatus='%s' WHERE filestatus ='%s' AND article_id_id='%s' AND activity='TYPE' AND user_name_id='%s';"
        cursor.execute(type_start_process_pause%(s,pause,a,u_name))

        type_start_process_pause1= "UPDATE Process_status_production_hours SET end_date='%s', pause_end_date='%s', filestatus='%s' WHERE article_id_id='%s' AND filestatus='p' AND activity='TYPE';"
        cursor.execute(type_start_process_pause1%(start_date,start_date,s,a))

    except ObjectDoesNotExist:
         return HttpResponse("<h2> current article is not present in database / already moved to next activity </h2>")
    articles.save()
    messages.success(request,"you get started")
    return redirect('latex_editor', article_num=a)



@login_required
@group_required(['Typesetting'])
def typeset_update_end(request, pk):
        articles = TYPEMODEL.Typeset.objects.get(id=pk)
        a = articles.article_id
#        a_p = articles.article_id_id
        article_title = IMODEL.Inventory_Upload.objects.get(article_id=a).title
        a_p = IMODEL.Inventory_Upload.objects.get(article_id=a).id
        aa = str(a)
        type_path = f'Typeset\\{a}'
        digit_path = f'Digitalization\\{a}'

        type_path = os.path.join(settings.STATIC_DIR, type_path)
        digit_path = os.path.join(settings.STATIC_DIR, digit_path)

        shutil.copytree(type_path, digit_path)

#        digit_path_tex_cmd = 'static/Digitalization/'+str(a)
        
#        digit_path_tex = digit_path+f'\\{a}.tex'
#        type_path_tex = type_path+f'\\{a}.tex'
        
        digit_path_media = digit_path+'\media'
        digit_path_pdf = digit_path+f'\\{a}.pdf'
        digit_path_html = digit_path+f'\\{a}.html'
        digit_path_log = digit_path+f'\\{a}.log'
        digit_path_aux = digit_path+f'\\{a}.aux'
        digit_path_qry = digit_path+f'\\{a}.qry'
        if os.path.exists(digit_path_media):
            shutil.rmtree(digit_path_media)
        if os.path.exists(digit_path_pdf):
            os.remove(digit_path_pdf)
        if os.path.exists(digit_path_html):
            os.remove(digit_path_html)
        if os.path.exists(digit_path_log):
            os.remove(digit_path_log)
        if os.path.exists(digit_path_aux):
            os.remove(digit_path_aux)
        if os.path.exists(digit_path_qry):
            os.remove(digit_path_qry)

#        with open(type_path_tex, 'r', encoding='utf8') as rf:
#            file_content = rf.read()
#            file_content = file_content.replace('d:/Django/bohr/bhors_tracking/static/New_Layout/cls/Bohr-v2','article')
#            file_content = file_content.replace('\\begin{document}','\\newcommand{\hypertarget}[2]{#2}\n\\begin{document}')
#            file_content = file_content.replace('\\begin{address}','\\newcommand{\hypertarget}[2]{#2}')
            
#        with open(digit_path_tex, 'w', encoding='utf8') as wf:
#            wf.write(file_content)
#        destination = 'static/Digitalization/'+str(a)+'/'+str(a)+'_prepost.xml'
#        digit_tex_file = 'static/Digitalization/'+str(a)+'/'+str(a)+'.tex'
#        print("digit_path_tex",digit_path_tex)
#        batch_file_path = 'latexpre.bat'
#        batch_file_path1 = 'latexpost.bat'
        xml_file = 'static/Digitalization/'+ aa +'/'+ aa + '.xml'
        epub_html_file = 'static/Digitalization/'+ aa +'/'+ aa + '.html'
#        try:
#            subprocess.run(['pdflatex', '-quiet', '-output-directory', pdf_output_path_folder, latex_file_path]
#            subprocess.run([r'latexml',
#            r'--destination=preprocess.xml', r'fncel-2021-1082181.tex'])
#            subprocess.run([batch_file_path, aa], shell=True)
#            subprocess.run([batch_file_path1, aa], shell=True)
#        except subprocess.CalledProcessError as e:
#            print(f"Error executing pdflatex command: {e}")
#        subprocess.run([batch_file_path, aa], shell=True)
#        subprocess.run([batch_file_path1, aa], shell=True)
        old_enc = '<?xml version="1.0"?>'
        new_enc = '<?xml version="1.0" encoding="UTF-8" standalone="no"?>'
        old_dtd = '<!DOCTYPE article PUBLIC "-//NLM//DTD JATS (Z39.96) Journal Publishing DTD v1.2 20190208//EN" "JATS-journalpublishing1-2.dtd">'
        old_dtd1 = '<!DOCTYPE article PUBLIC "-//NLM//DTD Journal Publishing DTD v2.3 20070202//EN" "journalpublishing.dtd">'
        new_dtd = ''
#        new_dtd = '<!DOCTYPE article PUBLIC "-//NLM//DTD JATS (Z39.96) Journal Publishing DTD v1.2 20190208//EN" "d:/Projects/Python/scripts/fncel-2021-1082181/journal-publishing-dtd-2.3/journalpublishing.dtd">'
        old_art = '<article>'
        new_art = '<article xmlns:mml="http://www.w3.org/1998/Math/MathML" xmlns:xlink="http://www.w3.org/1999/xlink" xml:lang="EN" article-type="article">'
        
        with open(xml_file, 'r+') as file:
            content = file.read()
            modified_content = content.replace(old_enc, new_enc)
            modified_content = modified_content.replace(old_dtd, new_dtd)
            modified_content = modified_content.replace(old_dtd1, new_dtd)
            modified_content = modified_content.replace(old_art, new_art)
            file.seek(0)
            file.write(modified_content)
            file.truncate()
        epub_html_cmd = 'epubfilecmd.bat'
        subprocess.run([epub_html_cmd, aa], shell=True)
        navfilecmd_cmd = 'navfilecmd.bat'
        subprocess.run([navfilecmd_cmd, aa], shell=True)
        coverfilecmd = 'coverfilecmd.bat'
        subprocess.run([coverfilecmd, aa], shell=True)
        packagefile = 'packagefile.bat'
        subprocess.run([packagefile, aa], shell=True)
        tocncdfile = 'tocncdfile.bat'
        subprocess.run([tocncdfile, aa], shell=True)

        htmlfile = 'htmlcreatefile.bat'
        subprocess.run([htmlfile, aa], shell=True)

        
        
########################################cover Image ########################################Area#####################
        from PIL import Image, ImageDraw, ImageFont

        # Define the dimensions of your cover image (in pixels)
        width = 1250
        height = 1634

        # Create a blank image with a white background
        background_color = (255, 255, 255)
        cover = Image.new("RGB", (width, height), background_color)

        # Load a font (provide the path to a TrueType font file)
        font = ImageFont.truetype("arial.ttf", size=72)

        # Create a drawing context
        draw = ImageDraw.Draw(cover)

        # Define the title text
        title_text = article_title
        text_color = (0, 0, 0)  # Black

        # Define the background box color
        box_color = (200, 200, 200)  # Light gray

        # Define the box dimensions
        box_width = 1100
        box_height = 400

        # Calculate the position of the box
        box_x = (width - box_width) / 2
        box_y = (height - box_height) / 2

        # Draw the background box
        draw.rectangle([box_x, box_y, box_x + box_width, box_y + box_height], fill=box_color)

        # Calculate the maximum width for the wrapped title text
        max_text_width = box_width - 40  # Adjust the padding as needed

        # Wrap the title text to fit within the box
        lines = []
        line = ""
        for word in title_text.split():
            if font.getbbox(line + word)[2] <= max_text_width:
                line += word + " "
            else:
                lines.append(line)
                line = word + " "
        lines.append(line)

        # Calculate the total height of the wrapped text
        text_height = len(lines) * font.getbbox(title_text)[3]

        # Calculate the vertical position to center the text within the box
        text_y = box_y + (box_height - text_height) / 2

        # Draw the wrapped title text within the box
        for line in lines:
            text_bbox = draw.textbbox((0, 0), line, font=font)
            text_width = text_bbox[2] - text_bbox[0]
            text_x = box_x + (box_width - text_width) / 2
            draw.text((text_x, text_y), line, fill=text_color, font=font)
            text_y += font.getbbox(title_text)[3]

        # Open and resize the logo image (provide the path to your logo file)
        logo = Image.open("logo.jpg")
        new_logo_size = (874, 60)  # Adjust the desired size
        logo = logo.resize(new_logo_size, Image.LANCZOS)  # Resizing with Lanczos resampling

        # Paste the resized logo onto the cover image
        cover.paste(logo, (80, 100))

        # Save the cover image
        cover.save("static/Digitalization/"+ aa +"/cover.png")

        # Close the image
        cover.close()

        shutil.copytree('OPS', digit_path+'/OPS')
        shutil.copytree('meta-inf', digit_path+'/meta-inf')
        shutil.copy2('mimetype', digit_path+'/mimetype')

        shutil.move("static/Digitalization/"+aa+"/package.opf", "static/Digitalization/"+aa+"/OPS/package.opf")
        shutil.move("static/Digitalization/"+aa+"/toc.ncx", "static/Digitalization/"+aa+"/OPS/toc.ncx")
        
        shutil.move("static/Digitalization/"+aa+"/"+aa+".xhtml", "static/Digitalization/"+aa+"/OPS/xhtml/"+aa+".xhtml")
        shutil.move("static/Digitalization/"+aa+"/Nav.xhtml", "static/Digitalization/"+aa+"/OPS/xhtml/Nav.xhtml")
        shutil.move("static/Digitalization/"+aa+"/cover.xhtml", "static/Digitalization/"+aa+"/OPS/xhtml/cover.xhtml")

        
        source_directories = ["static/Digitalization/"+aa]
        destination_directory = "static/Digitalization/"+aa+"/OPS/images"
        print(source_directories)
        print(type(source_directories))
        for source_dir in source_directories:
            files = os.listdir(source_dir)
            for file in files:
                source_file_path = os.path.join(source_dir, file)
                if file.lower().endswith(('.jpg', '.jpeg', '.png', '.gif', '.bmp')):
                    destination_file_path = os.path.join(destination_directory, file)
                    shutil.copy(source_file_path, destination_file_path)
        import zipfile

        # Define the names of the directories and files
        ops_dir = "static/Digitalization/"+aa+"/OPS"
        meta_inf_dir = "META-INF"
        mimetype_file = "mimetype"
        epub_file = "static/Digitalization/"+aa+"/"+aa+".epub"  # Change to your desired EPUB filename

        # Create an EPUB archive
        with zipfile.ZipFile(epub_file, "w") as epub:
            # Add mimetype file first (no compression)
            epub.write(mimetype_file, arcname=mimetype_file, compress_type=zipfile.ZIP_STORED)

            # Add META-INF directory and its contents
            for root, _, files in os.walk(meta_inf_dir):
                for file in files:
                    file_path = os.path.join(root, file)
                    rel_path = os.path.relpath(file_path, meta_inf_dir)
                    epub.write(file_path, arcname=os.path.join("META-INF", rel_path))

            # Add ops directory and its contents
            for root, _, files in os.walk(ops_dir):
                for file in files:
                    file_path = os.path.join(root, file)
                    rel_path = os.path.relpath(file_path, ops_dir)
                    epub.write(file_path, arcname=os.path.join("OPS", rel_path))
        if os.path.exists(ops_dir):
            shutil.rmtree(ops_dir)
        if os.path.exists("static/Digitalization/"+aa+"/META-INF"):
            shutil.rmtree("static/Digitalization/"+aa+"/META-INF")
        if os.path.exists("static/Digitalization/"+aa+"/mimetype"):
            os.remove("static/Digitalization/"+aa+"/mimetype")
        if os.path.exists("static/Typeset/"+aa+"/"+aa+".pdf"):
            shutil.copy2("static/Typeset/"+aa+"/"+aa+".pdf", "static/Digitalization/"+aa+"/"+aa+".pdf")
        start_date = timezone.now().strftime('%Y-%m-%d %H:%M:%S')
        st = 'c'
        sta = 'a'
        act = 'TYPE'
        act1 = 'DIGI'
        cursor = connection.cursor()
        
        try:
            typeset_end_update_inuse= "UPDATE Process_status_process_status SET end_date='%s', filestatus='%s'  WHERE  article_id_id='%s' AND activity='%s' AND filestatus = 'i';"
            cursor.execute(typeset_end_update_inuse%(start_date,st,a_p,act))

            typeset_end_update_resume= "UPDATE Process_status_process_status SET end_date='%s', filestatus='%s'  WHERE  article_id_id='%s' AND activity='%s' AND filestatus = 's';"
            cursor.execute(typeset_end_update_resume%(start_date,st,a_p,act))

            typeset_start_process_end1= "UPDATE Process_status_production_hours SET end_date='%s', filestatus='c'  WHERE  article_id_id='%s' AND filestatus='i' AND activity='L2ED';"
            cursor.execute(typeset_start_process_end1%(start_date,a_p))                    

            typeset_start_process_end2= "UPDATE Typeset_typeset SET end_date='%s', filestatus='c'  WHERE  article_id_id='%s' AND filestatus='i';"
            cursor.execute(typeset_start_process_end2%(start_date,a_p))                    
            
            typeset_user_end_Na = "INSERT INTO digitalization_digitalization(filestatus, article_id_id) VALUES ('%s','%s');"
            cursor.execute(typeset_user_end_Na%(sta, a_p))

            typeset_user_end_Na_process = "INSERT INTO Process_status_process_status (filestatus,activity,article_id_id) VALUES ('%s','%s','%s');"
            cursor.execute(typeset_user_end_Na_process%(sta,act1,a_p))

        except ObjectDoesNotExist:
            return HttpResponse("<h2> current article is not present in database / already moved to next activity </h2>")
        messages.success(request,"Digital Files are Generated")
        return redirect('typeset_process')
        ######################################################################################################################
        
#        command_epub_html_file = ['java', '-jar', 'Saxon-HE-9.8.0-12.jar', -s:xml_file, -xsl:static/ePub/ePub_xsl_files/jat2ePub.xsl, -o:epub_html_file]
#        command_nav_file = ['java', '-jar', 'Saxon-HE-9.8.0-12.jar', 'static/ePub/ePub_xsl_files/navigation.xsl', xml_file]
#        command_ncx_file = ['java', '-jar', 'Saxon-HE-9.8.0-12.jar', 'static/ePub/ePub_xsl_files/ncx_toc.xsl', xml_file]
#        command_package_file = ['java', '-jar', 'Saxon-HE-9.8.0-12.jar', 'static/ePub/ePub_xsl_files/package_opf.xsl', xml_file]
#        command_cover_file = ['java', '-jar', 'Saxon-HE-9.8.0-12.jar', 'static/ePub/ePub_xsl_files/cover_create.xsl', xml_file]
#        subprocess.run(command_epub_html_file)
#        subprocess.run(command_nav_file)
#        subprocess.run(command_ncx_file)
#        subprocess.run(command_package_file)
#        subprocess.run(command_cover_file)