from django import forms
from .models import *
from django.contrib.admin.widgets import AdminDateWidget, AdminTimeWidget





class typesetForm(forms.ModelForm):
    #article_id = forms.CharField(disabled=True)
    class Meta:
        model=Typeset
        fields=['add_remarks', 'add_comments']
        widgets = {
        "start_date":  AdminDateWidget(),
        "start_time":  AdminTimeWidget(),
        "end_date":  AdminDateWidget(),
        "end_time":  AdminTimeWidget(),
        }