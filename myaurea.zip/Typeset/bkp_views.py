from django.shortcuts import render
from inventory import models as IMODEL
from django.contrib.auth.models import User
from django.db import connection
from django.shortcuts import redirect, render
from django.utils import timezone
import os
from django.conf import settings
from Typeset import models as TYPEMODEL
from django.contrib import messages
from django.http import (HttpResponse)
from django.core.exceptions import ObjectDoesNotExist
from .forms import*
import shutil
# Create your views here.
from Typeset import models as TYPEMODEL
def typeset_process(request):
    articles = TYPEMODEL.Typeset.objects.all()
#    user_name_id = l1_articles.user_name_id
    
    return render(request,'typeset/typeset_process.html',{'articles':articles})

def typeset_start(request,pk):
    articles = TYPEMODEL.Typeset.objects.get(id=pk)
    a = articles.article_id
    article_id_ID = IMODEL.Inventory_Upload.objects.get(article_id=a).pk
    print("This are articles by ravi:",articles)
    user = request.user
    u_name = User.objects.get(username=user).pk
    start_date = timezone.now().strftime('%Y-%m-%d %H:%M:%S')
    sta = 'i'
    act ='typeset'
    articles.user_name=user
    articles.start_date=start_date
    articles.filestatus=sta
    cursor = connection.cursor()

    if TYPEMODEL.Typeset.objects.filter(article_id = article_id_ID).exists():
        messages.warning(request,"Some one Already Started Process Please choise another article ")
        return redirect('typeset_process')
    else:
        typeset_update_process= "UPDATE Process_status_process_status SET start_date='%s', filestatus='i', user_name_id='%s' WHERE article_id_id='%s' and activity='%s';"
        cursor.execute(typeset_update_process%(start_date, u_name, article_id_ID, act))

        Copy_Edit_Completion_start_process1 = "INSERT INTO Process_status_production_hours (article_id_id,start_date,user_name_id,filestatus,activity) VALUES ('%s','%s','%s','%s','%s');"
        cursor.execute(Copy_Edit_Completion_start_process1%(article_id_ID,start_date,u_name,sta,act))
    articles.save()

    return redirect('typeset_edit_file', article_num = article_id_ID, file_path=f'L2Edit/{a}/{a}.html')






def typeset_inuse(request,pk):
    articles = TYPEMODEL.Typeset.objects.get(id=pk)
    a = articles.article_id
    article_id_ID = IMODEL.Inventory_Upload.objects.get(article_id=a).pk

    return redirect('typeset_edit_file', article_num = article_id_ID, file_path=f'L2Edit/{a}/{a}.html')



 
def typeset_edit_file(request, article_num, file_path):
    articles = TYPEMODEL.Typeset.objects.all()
#    user_name_id =  articles.user_name_id
    file_path = os.path.join(settings.STATIC_DIR, file_path)
    file_path = file_path.replace("\\", "/")
    with open(file_path, 'r', encoding='utf8') as f:
        file_content = f.read()
        file_content = file_content.replace('mml:','')
    return render(request, 'Typeset/typeset_edit_file.html', {'file_content': file_content, 'article_num':article_num, 'file_path': file_path, 'articles':articles})

#def l2save_file(request, pk):
#    file_content = request.POST.get('file_content')
#    file_path = request.POST.get('file_path')
#    with open(file_path, 'w', encoding='utf8') as f:
#        f.write(file_content)
#    return redirect('typeset_edit_file', article_num=pk, file_path=file_path)

import pathlib

def l2save_file(request, pk):
    file_content = request.POST.get('file_content')
    file_path = request.POST.get('file_path')

    try:
        path = pathlib.Path(file_path)
        with path.open('w', encoding='utf8') as f:
            f.write(file_content)
    except IOError as e:
        print('Exception occurred while saving the file:', e)
        # Handle the exception appropriately
        return HttpResponseServerError('Error occurred while saving the file.')

    return redirect('typeset_edit_file', article_num=pk, file_path=file_path)


def typeset_edit_update_pause_start(request, pk):
    try:
        articles = TYPEMODEL.typeset.objects.get(id=pk)
        a = articles.article_id_id
        a_name = articles.article_id
        articles.filestatus = 'p'
        s = 'p'
        user = request.user
        
        articles.user_name=user
        u_name = User.objects.get(username=user).pk
        start_date = timezone.now().strftime('%Y-%m-%d %H:%M:%S')
        articles.start_date = start_date
        act = 'L2ED'
        inuse = 'i'        
        cursor = connection.cursor()
        typeset_start_process_pause= "UPDATE Process_status_process_status SET filestatus='%s' WHERE article_id_id ='%s' AND activity='L2ED' AND user_name_id ='%s' AND filestatus ='%s';"
        cursor.execute(typeset_start_process_pause%(s,a,u_name,inuse))

        typeset_start_process_pause1 = "INSERT INTO Process_status_production_hours (article_id_id,start_date,pause_date,user_name_id,filestatus,activity) VALUES ('%s','%s','%s','%s','%s','%s');"
        cursor.execute(typeset_start_process_pause1%(a,start_date,start_date,u_name,s,act))
    except ObjectDoesNotExist:
         return HttpResponse("<h2> current article is not present in database / already moved to next activity </h2>")
    articles.save()
    messages.warning(request,"you stopped the work")
    return redirect('typeset_edit_file', article_num=a, file_path=f'L2Edit/{a_name}/{a_name}.html')


def typeset_edit_update_pause_end(request, pk):
    articles = TYPEMODEL.typeset.objects.get(id=pk)
    try:
        start_date = timezone.now().strftime('%Y-%m-%d %H:%M:%S')
        articles.start_date = start_date
        a = articles.article_id_id
        a_name = articles.article_id
        articles.filestatus = 's'
        s = 's'
        pause ='p'
        user = request.user
        
        articles.user_name=user
        u_name = User.objects.get(username=user).pk
        file_path = request.POST.get('file_path')
        cursor = connection.cursor()
        typeset_start_process_pause= "UPDATE Process_status_process_status SET filestatus='%s' WHERE filestatus ='%s' AND article_id_id='%s' AND activity='L2ED' AND user_name_id='%s';"
        cursor.execute(typeset_start_process_pause%(s,pause,a,u_name))

        typeset_start_process_pause1= "UPDATE Process_status_production_hours SET end_date='%s', pause_end_date='%s', filestatus='%s' WHERE article_id_id='%s' AND filestatus='p' AND activity='L2ED';"
        cursor.execute(typeset_start_process_pause1%(start_date,start_date,s,a))

    except ObjectDoesNotExist:
         return HttpResponse("<h2> current article is not present in database / already moved to next activity </h2>")
    articles.save()
    messages.success(request,"you get started")
    return redirect('typeset_edit_file', article_num=a, file_path=f'L2Edit/{a_name}/{a_name}.html')



def typeset_update_end(request, pk):
        articles = TYPEMODEL.typeset.objects.get(id=pk)
        a = articles.article_id
        file_path=f'L2Edit/{a}'
        typeset = f'Typeset/{a}'
        src_path = os.path.join(settings.STATIC_DIR, file_path)
        dst_path = os.path.join(settings.STATIC_DIR, typeset)
        
        
        file_status = articles.filestatus
        form = l2editForm(request.POST or None, instance=articles)  
        if file_status != 'p':        
            if form.is_valid():
                start_date = timezone.now().strftime('%Y-%m-%d %H:%M:%S')
                articles.end_date = start_date
                form.data._mutable=True
                user = request.user
                articles.user_name = user
                a = articles.article_id_id

                user = request.user
                u_name = User.objects.get(username=user).pk

                u = str(user)
                sta = 'a'
                act1 = 'TYPE'
                st = 'c'
                articles.filestatus = 'c'
                file_status = articles.filestatus
                c = articles.add_comments
                r=articles.add_remarks
                act ='type'
                cursor = connection.cursor()

                try:
                    l2edit_end_update_inuse= "UPDATE Process_status_process_status SET end_date='%s', filestatus='%s'  WHERE  article_id_id='%s' AND activity='%s' AND filestatus = 'i';"
                    cursor.execute(l2edit_end_update_inuse%(start_date,st,a,act))

                    l2edit_end_update_resume= "UPDATE Process_status_process_status SET end_date='%s', filestatus='%s'  WHERE  article_id_id='%s' AND activity='%s' AND filestatus = 's';"
                    cursor.execute(l2edit_end_update_resume%(start_date,st,a,act))

                    l2edit_start_process_end1= "UPDATE Process_status_production_hours SET end_date='%s', filestatus='c'  WHERE  article_id_id='%s' AND filestatus='i' AND activity='L2ED';"
                    cursor.execute(l2edit_start_process_end1%(start_date,a))                    


                    l2edit_user_end_Na = "INSERT INTO Typeset_typeset(filestatus, add_comments, add_remarks, article_id_id) VALUES ('%s','%s','%s','%s');"
                    cursor.execute(l2edit_user_end_Na%(sta, c, r, a))

                    l2edit_user_end_Na_process = "INSERT INTO Process_status_process_status (filestatus,activity,article_id_id) VALUES ('%s','%s','%s');"
                    cursor.execute(l2edit_user_end_Na_process%(sta,act1,a))
            
                except ObjectDoesNotExist:
                    return HttpResponse("<h2> current article is not present in database / already moved to next activity </h2>")

                shutil.copytree(src_path, dst_path)
                form.save()
                messages.success(request,"sucessfully file was compleated")
                return redirect('typeset_process')
        else:
            messages.warning(request,"Please Close your break time")
            return redirect('typeset_process')            
        return render(request, 'l2edit/typeset_complete_process_update_end.html',{'articles':articles,'form':form})
    