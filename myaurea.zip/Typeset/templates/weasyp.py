from weasyprint import HTML
pdf_file_path = './output.pdf'
# Read the HTML file
with open('stest.html', 'r') as file:
    html_content = file.read()

# Create an HTML object with the rendered MathML
pdf = HTML(string=html_content).write_pdf(weasyprint_pdf_kwargs={'pdf_engine': 'cairo'})
#html = HTML(string=html_content)
# Convert HTML to PDF using WeasyPrint
with open(pdf_file_path, 'wb') as pdf_file:
    pdf_file.write(pdf)
