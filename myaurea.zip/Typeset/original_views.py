from django.shortcuts import render
from inventory import models as IMODEL
from django.contrib.auth.models import User
from django.db import connection
from django.shortcuts import redirect, render
from django.utils import timezone
import os, subprocess, shutil
from django.conf import settings
from Typeset import models as TYPEMODEL
from django.contrib import messages
from django.http import HttpResponse
from django.core.exceptions import ObjectDoesNotExist
from .forms import*
# Create your views here.
from Typeset import models as TYPEMODEL
from django.template.loader import render_to_string

def typeset_process(request):
    articles = TYPEMODEL.Typeset.objects.all()
#    user_name_id = l1_articles.user_name_id
    
    return render(request,'./typeset/typeset_process.html',{'articles':articles})

from django.middleware.csrf import get_token
def latex_editor(request):
#    const engine = new PdfTeXEngine();
#    await engine.loadEngine();
    html_file_path = 'static/Typeset/fncel-2020-1080021/fncel-2020-1080021.html'
    latex_file_path = 'static/Typeset/fncel-2020-1080021/fncel-2020-1080021.tex'
    pdf_output_path = './../static/Typeset/fncel-2020-1080021/fncel-2020-1080021.pdf'

    if request.method == 'POST':
        latex_content = request.POST.get('latex_content')
        latex_content = '\n'.join(line.strip() for line in latex_content.split('\n'))

        # Update the LaTeX file with the modified content
        with open(latex_file_path, 'w', encoding="utf8") as f:
            f.write(latex_content)

        # Regenerate the PDF output
        try:
            subprocess.run(['pdflatex', '-quiet', '-output-directory', 'static/Typeset/fncel-2020-1080021', latex_file_path])
#            subprocess.run(['pandoc', '--pdf-engine=lualatex', latex_file_path, '-o', pdf_output_path])
        except subprocess.CalledProcessError as e:
            print(f"Error executing pdflatex command: {e}")
            # Handle the error, log it, or return an appropriate response
#        subprocess.run(['pdflatex', '-output-directory', 'static/Typeset/fncel-2020-1080021', latex_file_path])

    # Read the LaTeX file
    with open(latex_file_path, 'r', encoding="utf8") as f:
        latex_content = f.read().strip()
        
    # Render the template with the LaTeX content and PDF output path
    csrf_token = get_token(request)
    context = {
        'latex_content': latex_content,
        'pdf_output_path': pdf_output_path,
#        'csrf_token': csrf_token,
    }
    #html = render_to_string('typeset/typeset_edit_file.html', context)
    return render(request, 'typeset/typeset_edit_file.html', context)
    #return HttpResponse(html)

def save_latex_file(request, pk):
    file_content = request.POST.get('file_content')
    file_path = request.POST.get('file_path')

    try:
        path = pathlib.Path(file_path)
        with path.open('w', encoding='utf8') as f:
            f.write(file_content)
    except IOError as e:
        print('Exception occurred while saving the file:', e)
        # Handle the exception appropriately
        return HttpResponseServerError('Error occurred while saving the file.')

    return redirect('latex_editor', article_num=pk, file_path=file_path)

from weasyprint import HTML

def generate_pdf(request):
    html_content = '''
    <!DOCTYPE html>
    <html>
    <head>
        <title>HTML to PDF</title>
        <style>
            /* Styles for web browser display */
            @media screen {
                .container {
                    width: 100%; /* Full-width container */
                }
                .column {
                    width: 50%; /* Two columns */
                    box-sizing: border-box; /* Include padding and border in the width */
                    margin: 10px; /* Add margin to prevent content overlap */
                }
            }

            /* Styles for PDF/print output */
            @media print {
                .container {
                    width: 100%; /* Full-width container */
                }
                .column {
                    width: 50%; /* Single column for PDF */
                    box-sizing: border-box; /* Include padding and border in the width */
                    margin: 10px; /* Add margin to prevent content overlap */
                }
            }
        </style>
    </head>
    <body>
        <div class="container">
            <div class="column">Column 1</div>
            <div class="column">Column 2</div>
        </div>
    </body>
    </html>
    '''

    pdf_data = HTML(string=html_content).write_pdf()

    response = HttpResponse(content_type='application/pdf')
    response['Content-Disposition'] = 'filename="output.pdf"'
    response.write(pdf_data)

    return response
    
"""

def typeset_inuse(request,pk):
    articles = TYPEMODEL.Typeset.objects.get(id=pk)
    a = articles.article_id
    article_id_ID = IMODEL.Inventory_Upload.objects.get(article_id=a).pk

    return redirect('typeset_edit_file', article_num = article_id_ID, file_path=f'L2Edit/{a}/{a}.html')



 
def typeset_edit_file(request, article_num, file_path):
    articles = TYPEMODEL.Typeset.objects.all()
#    user_name_id =  articles.user_name_id
    file_path = os.path.join(settings.STATIC_DIR, file_path)
    file_path = file_path.replace("\\", "/")
    with open(file_path, 'r', encoding='utf8') as f:
        file_content = f.read()
        file_content = file_content.replace('mml:','')
    return render(request, 'Typeset/typeset_edit_file.html', {'file_content': file_content, 'article_num':article_num, 'file_path': file_path, 'articles':articles})

#def l2save_file(request, pk):
#    file_content = request.POST.get('file_content')
#    file_path = request.POST.get('file_path')
#    with open(file_path, 'w', encoding='utf8') as f:
#        f.write(file_content)
#    return redirect('typeset_edit_file', article_num=pk, file_path=file_path)

import pathlib

def l2save_file(request, pk):
    file_content = request.POST.get('file_content')
    file_path = request.POST.get('file_path')

    try:
        path = pathlib.Path(file_path)
        with path.open('w', encoding='utf8') as f:
            f.write(file_content)
    except IOError as e:
        print('Exception occurred while saving the file:', e)
        # Handle the exception appropriately
        return HttpResponseServerError('Error occurred while saving the file.')

    return redirect('typeset_edit_file', article_num=pk, file_path=file_path)


def typeset_edit_update_pause_start(request, pk):
    try:
        articles = TYPEMODEL.typeset.objects.get(id=pk)
        a = articles.article_id_id
        a_name = articles.article_id
        articles.filestatus = 'p'
        s = 'p'
        user = request.user
        
        articles.user_name=user
        u_name = User.objects.get(username=user).pk
        start_date = timezone.now().strftime('%Y-%m-%d %H:%M:%S')
        articles.start_date = start_date
        act = 'L2ED'
        inuse = 'i'        
        cursor = connection.cursor()
        typeset_start_process_pause= "UPDATE Process_status_process_status SET filestatus='%s' WHERE article_id_id ='%s' AND activity='L2ED' AND user_name_id ='%s' AND filestatus ='%s';"
        cursor.execute(typeset_start_process_pause%(s,a,u_name,inuse))

        typeset_start_process_pause1 = "INSERT INTO Process_status_production_hours (article_id_id,start_date,pause_date,user_name_id,filestatus,activity) VALUES ('%s','%s','%s','%s','%s','%s');"
        cursor.execute(typeset_start_process_pause1%(a,start_date,start_date,u_name,s,act))
    except ObjectDoesNotExist:
         return HttpResponse("<h2> current article is not present in database / already moved to next activity </h2>")
    articles.save()
    messages.warning(request,"you stopped the work")
    return redirect('typeset_edit_file', article_num=a, file_path=f'L2Edit/{a_name}/{a_name}.html')


def typeset_edit_update_pause_end(request, pk):
    articles = TYPEMODEL.typeset.objects.get(id=pk)
    try:
        start_date = timezone.now().strftime('%Y-%m-%d %H:%M:%S')
        articles.start_date = start_date
        a = articles.article_id_id
        a_name = articles.article_id
        articles.filestatus = 's'
        s = 's'
        pause ='p'
        user = request.user
        
        articles.user_name=user
        u_name = User.objects.get(username=user).pk
        file_path = request.POST.get('file_path')
        cursor = connection.cursor()
        typeset_start_process_pause= "UPDATE Process_status_process_status SET filestatus='%s' WHERE filestatus ='%s' AND article_id_id='%s' AND activity='L2ED' AND user_name_id='%s';"
        cursor.execute(typeset_start_process_pause%(s,pause,a,u_name))

        typeset_start_process_pause1= "UPDATE Process_status_production_hours SET end_date='%s', pause_end_date='%s', filestatus='%s' WHERE article_id_id='%s' AND filestatus='p' AND activity='L2ED';"
        cursor.execute(typeset_start_process_pause1%(start_date,start_date,s,a))

    except ObjectDoesNotExist:
         return HttpResponse("<h2> current article is not present in database / already moved to next activity </h2>")
    articles.save()
    messages.success(request,"you get started")
    return redirect('typeset_edit_file', article_num=a, file_path=f'L2Edit/{a_name}/{a_name}.html')



def typeset_update_end(request, pk):
        articles = TYPEMODEL.typeset.objects.get(id=pk)
        a = articles.article_id
        file_path=f'L2Edit/{a}'
        typeset = f'Typeset/{a}'
        src_path = os.path.join(settings.STATIC_DIR, file_path)
        dst_path = os.path.join(settings.STATIC_DIR, typeset)
        
        
        file_status = articles.filestatus
        form = l2editForm(request.POST or None, instance=articles)  
        if file_status != 'p':        
            if form.is_valid():
                start_date = timezone.now().strftime('%Y-%m-%d %H:%M:%S')
                articles.end_date = start_date
                form.data._mutable=True
                user = request.user
                articles.user_name = user
                a = articles.article_id_id

                user = request.user
                u_name = User.objects.get(username=user).pk

                u = str(user)
                sta = 'a'
                act1 = 'TYPE'
                st = 'c'
                articles.filestatus = 'c'
                file_status = articles.filestatus
                c = articles.add_comments
                r=articles.add_remarks
                act ='type'
                cursor = connection.cursor()

                try:
                    l2edit_end_update_inuse= "UPDATE Process_status_process_status SET end_date='%s', filestatus='%s'  WHERE  article_id_id='%s' AND activity='%s' AND filestatus = 'i';"
                    cursor.execute(l2edit_end_update_inuse%(start_date,st,a,act))

                    l2edit_end_update_resume= "UPDATE Process_status_process_status SET end_date='%s', filestatus='%s'  WHERE  article_id_id='%s' AND activity='%s' AND filestatus = 's';"
                    cursor.execute(l2edit_end_update_resume%(start_date,st,a,act))

                    l2edit_start_process_end1= "UPDATE Process_status_production_hours SET end_date='%s', filestatus='c'  WHERE  article_id_id='%s' AND filestatus='i' AND activity='L2ED';"
                    cursor.execute(l2edit_start_process_end1%(start_date,a))                    


                    l2edit_user_end_Na = "INSERT INTO Typeset_typeset(filestatus, add_comments, add_remarks, article_id_id) VALUES ('%s','%s','%s','%s');"
                    cursor.execute(l2edit_user_end_Na%(sta, c, r, a))

                    l2edit_user_end_Na_process = "INSERT INTO Process_status_process_status (filestatus,activity,article_id_id) VALUES ('%s','%s','%s');"
                    cursor.execute(l2edit_user_end_Na_process%(sta,act1,a))
            
                except ObjectDoesNotExist:
                    return HttpResponse("<h2> current article is not present in database / already moved to next activity </h2>")

                shutil.copytree(src_path, dst_path)
                form.save()
                messages.success(request,"sucessfully file was compleated")
                return redirect('typeset_process')
        else:
            messages.warning(request,"Please Close your break time")
            return redirect('typeset_process')            
        return render(request, 'l2edit/typeset_complete_process_update_end.html',{'articles':articles,'form':form})
import js
from js.external import jspdf
def generate_pdf(request):
    jsPDF = js.require('jspdf')
  # Get the HTML content of the file
    html_file_path = 'static/Typeset/fncel-2020-1080021/fncel-2020-1080021.html'
    with open(html_file_path, 'r') as f:
        html = f.read()
    doc = jsPDF()
  # Create a new jsPDF object
#    doc = new jsPDF();

# Pass the HTML content to the fromHTML() method
    doc.fromHTML(html, 20, 20, {
#    // Set the width of the PDF
    width: 1000,
#   // Set the height of the PDF
    height: 500
  });

  # Save the PDF
    doc.save('my-pdf.pdf');

    return render(request, 'pdf.html', {
    'pdf_url': 'my-pdf.pdf'
  });
"""
from weasyprint import HTML
from django.http import HttpResponse
def html_to_pdf(request):
    # Render the HTML5 page
    html_file_path = 'static/Typeset/fncel-2020-1080021/fncel-2020-1080021.html'
    pdf_file_path = 'static/Typeset/fncel-2020-1080021/output.pdf'
    with open(html_file_path, 'r') as f:
        html_content = f.read()
    pdf = HTML(string=html_content).write_pdf(weasyprint_pdf_kwargs={'pdf_engine': 'cairo'})

    # Save PDF file
    with open(pdf_file_path, 'wb') as pdf_file:
        pdf_file.write(pdf)
    
    # Return the PDF as a response
    response = HttpResponse(content_type='application/pdf')
    response['Content-Disposition'] = 'inline; filename="output.pdf"'
    response.write(pdf)
    
    return response
def pdf_viewer(request):
    return render(request, 'pdf_viewer.html')