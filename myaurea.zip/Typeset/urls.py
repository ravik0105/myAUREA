from django.contrib import admin
from . import views
from . views import*
from django.views.i18n import JavaScriptCatalog
from django.urls import path
from django.core.exceptions import *


urlpatterns = [

     path('typeset_process/', views.typeset_process, name='typeset_process'),
     path('latex_editor/<int:article_num>/', views.latex_editor, name='latex_editor'),
#     path('pdf_viewer/', pdf_viewer, name='pdf_viewer'),
#     path('generate_pdf', generate_pdf, name='generate_pdf'),
 #     path('edit/<int:article_num>/<path:file_path>/', latex_editor, name='latex_editor'),
     path('typeset_start/<int:pk>', views.typeset_start, name='typeset_start'),
#     path('edit/<int:article_num>/<path:file_path>/', typeset_edit_file, name='typeset_edit_file'),
#     path('typeset_inuse/<int:pk>', views.typeset_inuse, name='typeset_inuse'),

    path('typeset_edit_update_pause_start/<int:pk>', views.typeset_edit_update_pause_start,name='typeset_edit_update_pause_start'),
    path('typeset_edit_update_pause_end/<int:pk>', views.typeset_edit_update_pause_end,name='typeset_edit_update_pause_end'),
    path('typeset_update_end/<int:pk>', views.typeset_update_end, name="typeset_update_end"),
]