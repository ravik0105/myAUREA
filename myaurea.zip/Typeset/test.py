square = lambda x: x+2
result = square(5)
print(result)  # Output: 25
