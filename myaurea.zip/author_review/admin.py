from django.contrib import admin
from .models import Author_review
# Register your models here.

class author_review_admin (admin.ModelAdmin):

    list_display = ('article_id','rec_date','filestatus')
    list_filter = ('filestatus',)
    search_fields = ['article_id__id__icontains']
    
    
    def rec_date(self, obj):
        return obj.article_id.received_date if obj.article_id else None

    def figures(self, obj):
        return obj.article_id.figures

    def Pages(self, obj):
        return obj.article_id.pages





# admin.site.register(Author_review, author_review_admin)