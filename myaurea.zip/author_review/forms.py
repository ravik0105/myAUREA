from django import forms
from .models import *
from django.contrib.admin.widgets import AdminDateWidget, AdminTimeWidget

 
class authourreviewform(forms.ModelForm):

    class Meta:
        model = Author_review
        fields = ['author_review_status',  'add_remarks', 'add_comments']
        widgets = {
            "start_date": AdminDateWidget(),
            "start_time": AdminTimeWidget(),
            "end_date": AdminDateWidget(),
            "end_time": AdminTimeWidget(),
        }

    # Set author_review_status with default value and make it not required
    author_review_status = forms.ChoiceField(
        choices=[('', '------------')] + list(Author_review.FILE_STATUS),
        required=False,
    )