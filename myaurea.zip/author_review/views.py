from django.shortcuts import redirect, render
from inventory import models as IMODEL
from .forms import*
from author_review import models as ARMODEL
from django.contrib import messages
from django.db import connection
import os, shutil
from django.core.exceptions import ObjectDoesNotExist
from django.contrib.auth.models import User, Group
from django.utils.timezone import datetime
from django.utils import timezone
from django.conf import settings
from django.http import (HttpResponse, HttpResponseBadRequest, HttpResponseForbidden)
from django.contrib.auth.decorators import login_required
from .decorators import group_required
from django.db.models import Count



@login_required
@group_required(['author_review'])

def author_review_process(request):
    user_email = request.user.email
    articles = IMODEL.Inventory_Upload.objects.filter(correspondance_email=user_email)[:6]
    print("user_email",user_email)
    articles_count = ARMODEL.Author_review.objects.filter(Q(filestatus='a') | Q(filestatus='i')).annotate(count=Count('id')).order_by('filestatus').count()
    ar_articles_available = ARMODEL.Author_review.objects.filter(filestatus='a', article_id__in=articles)
    ar_articles_process = ARMODEL.Author_review.objects.filter(filestatus='i', article_id__in=articles)
    return render(request, 'Author_review/authour_review_process.html', {'ar_articles_available': ar_articles_available, 'ar_articles_process':ar_articles_process, 'articles_count':articles_count})



@login_required
@group_required(['author_review'])

def author_review_start(request,pk):
    articles = ARMODEL.Author_review.objects.get(id=pk)
    a = articles.article_id
    article_id_ID = IMODEL.Inventory_Upload.objects.get(article_id=a).pk
    user = request.user
    u_name = User.objects.get(username=user).pk
    start_date = timezone.now().strftime('%Y-%m-%d %H:%M:%S')
    sta = 'i'
    act ='AURW'
    articles.user_name=user
    articles.start_date=start_date
    articles.filestatus=sta
    cs = articles.correction_status
    cr = articles.author_review_status
    print('cr is', cr)
    cursor = connection.cursor()

    author_review_update_process= "UPDATE Process_status_process_status SET start_date='%s', filestatus='i', user_name_id='%s' WHERE article_id_id='%s' and activity='%s';"
    cursor.execute(author_review_update_process%(start_date, u_name, article_id_ID, act))

    author_review_start_process_production = "INSERT INTO Process_status_production_hours (article_id_id,start_date,user_name_id,filestatus,activity) VALUES ('%s','%s','%s','%s','%s');"
    cursor.execute(author_review_start_process_production%(article_id_ID,start_date,u_name,sta,act))
    articles.save()
    if cr == 'cr' and cs != None:
        return redirect('author_review_edit_file', article_num = article_id_ID, file_path=f'author_review/{a}_{cs}/{a}.html')
    else:
        return redirect('author_review_edit_file', article_num = article_id_ID, file_path=f'author_review/{a}/{a}.html')



@login_required
@group_required(['author_review'])

def author_review_edit_file(request, article_num, file_path):
    articles = ARMODEL.Author_review.objects.all()
    file_path = os.path.join(settings.STATIC_DIR, file_path)
    file_path = file_path.replace("\\", "/")
    with open(file_path, 'r', encoding='utf8') as f:
        file_content = f.read()
        file_content = file_content.replace('mml:','')
    return render(request, 'Author_review/author_edit_file.html', {'file_content': file_content, 'article_num':article_num, 'file_path': file_path, 'articles':articles})




@login_required
@group_required(['author_review'])

def author_review_save_file(request, pk):
    file_content = request.POST.get('file_content')
    file_path = request.POST.get('file_path')
    with open(file_path, 'w', encoding='utf8') as f:
        f.write(file_content)
    return redirect('author_review_edit_file', article_num=pk, file_path=file_path)



@login_required
@group_required(['author_review'])

def author_review_end(request, pk):
        articles = ARMODEL.Author_review.objects.get(id=pk)
        a_num = articles.article_id
        form = authourreviewform(request.POST or None, instance=articles)
        file_status = articles.filestatus
        if file_status != 'p':
            if form.is_valid():
                start_date = timezone.now().strftime('%Y-%m-%d %H:%M:%S')
                articles.end_date = start_date
                form.data._mutable=True
                user = request.user
                articles.user_name = user
                a = articles.article_id_id
                user = request.user
                u_name = User.objects.get(username=user).pk
                u = str(user)
                sta = 'a'
                act1 = 'AUCR'
                file_status = articles.filestatus
                articles.filestatus = 'c'
                c = articles.add_comments
                r=articles.add_remarks
                ars = articles.author_review_status
                cs = articles.correction_status
                ars1 = 'nc'
                if cs == None:
                    cs = 'C1'
                elif cs == 'C1':
                    cs = 'C2'
                elif cs == 'C2':
                    cs = 'C3'
                elif cs == 'C3':
                    cs = 'C4'
                elif cs == 'C4':
                    cs = 'C5'
                else:
                    cs = ''
                crs = articles.correction_status
                
                act ='AURW'
                act2 = 'TYPE'
                cursor = connection.cursor()
                if ars is not None:
                    try:    
                        author_review_end_update_inuse= "UPDATE Process_status_process_status SET end_date='%s',filestatus='c'  WHERE  article_id_id='%s' AND activity='%s' AND filestatus = 'i';"
                        cursor.execute(author_review_end_update_inuse%(start_date,a,act))

                        author_review_end_update_resume= "UPDATE Process_status_process_status SET end_date='%s',filestatus='c'  WHERE  article_id_id='%s' AND activity='%s' AND filestatus = 's';"
                        cursor.execute(author_review_end_update_resume%(start_date,a,act))

                        author_review_start_process_end1= "UPDATE Process_status_production_hours SET end_date='%s', filestatus='c'  WHERE  article_id_id='%s' AND filestatus='i' AND activity='AURW';"
                        cursor.execute(author_review_start_process_end1%(start_date,a))

                        # if ars == 'cr':
                        #     author_review_user_end_Na = "INSERT INTO author_correction_Author_correction(filestatus, author_review_status, correction_status, add_comments, add_remarks, article_id_id) VALUES ('%s','%s','%s','%s','%s','%s');"
                        #     cursor.execute(author_review_user_end_Na%(sta, ars, cs, c, r, a))

                        #     author_review_user_end_Na_process = "INSERT INTO Process_status_process_status (filestatus, author_review_status, correction_status, activity, article_id_id) VALUES ('%s','%s','%s','%s','%s');"
                        #     cursor.execute(author_review_user_end_Na_process%(sta, ars, cs, act1, a))
                        # else:
                        #     author_review_user_end_No_correction = "INSERT INTO Typeset_Typeset(filestatus, add_comments, add_remarks, article_id_id) VALUES ('%s','%s','%s','%s');"
                        #     cursor.execute(author_review_user_end_No_correction%(sta, c, r, a))

                        #     author_review_user_end_No_correction_process = "INSERT INTO Process_status_process_status (filestatus, author_review_status, correction_status, activity, article_id_id) VALUES ('%s','%s','%s','%s','%s');"
                        #     cursor.execute(author_review_user_end_No_correction_process%(sta, ars1, cs1, act2, a))


                        author_review_user_end_Na = "INSERT INTO author_correction_Author_correction(filestatus, author_review_status, correction_status, add_comments, add_remarks, article_id_id) VALUES ('%s','%s','%s','%s','%s','%s');"
                        cursor.execute(author_review_user_end_Na%(sta, ars, cs, c, r, a))

                        author_review_user_end_Na_process = "INSERT INTO Process_status_process_status (filestatus, author_review_status, correction_status, activity, article_id_id) VALUES ('%s','%s','%s','%s','%s');"
                        cursor.execute(author_review_user_end_Na_process%(sta, ars, cs, act1, a))
                        
                        # else:
                        #     author_review_user_end_No_correction = "INSERT INTO author_correction_Author_correction(filestatus, author_review_status, correction_status, add_comments, add_remarks, article_id_id) VALUES ('%s','%s','%s','%s','%s','%s');"
                        #     cursor.execute(author_review_user_end_No_correction%(sta, ars, cs1, c, r, a))

                        #     author_review_user_end_No_correction_process = "INSERT INTO Process_status_process_status (filestatus, author_review_status, correction_status, activity, article_id_id) VALUES ('%s','%s','%s','%s','%s');"
                        #     cursor.execute(author_review_user_end_No_correction_process%(sta, ars, cs1, act1, a))
        
                    except ObjectDoesNotExist:
                        return HttpResponse("<h2> current article is not present in database / already moved to next activity </h2>")

                    form.save()
                    file_path=f'author_review/{a_num}'
                    author_review = f'author_correction/{a_num}'
                    
                                
                    if cs == 'C2':
                        crs = 'C1'
                    elif cs == 'C3':
                        crs = 'C2'
                    elif cs == 'C4':
                        crs = 'C3'
                    elif cs == 'C5':
                        crs = 'C4'
                    elif cs == 'C6':
                        crs = 'C5'

                    if ars == 'cr':
                        if cs == "C1":
                            file_path=f'author_review/{a_num}'
                            author_review += f'_{cs}'
                            src_path = os.path.join(settings.STATIC_DIR, file_path)
                            dst_path = os.path.join(settings.STATIC_DIR, author_review)
                            shutil.copytree(src_path, dst_path)
                        else:
                            file_path += f'_{crs}'
                            author_review += f'_{cs}'
                            src_path = os.path.join(settings.STATIC_DIR, file_path)
                            dst_path = os.path.join(settings.STATIC_DIR, author_review)
                            shutil.copytree(src_path, dst_path)


                    elif ars == 'nc' and (cs is not None and cs != 'C1' and cs != 'Null'):

                        print ('cs is :',cs)
                        file_path += f'_{crs}'
                        author_review += f'_{cs}'
                        src_path = os.path.join(settings.STATIC_DIR, file_path)
                        dst_path = os.path.join(settings.STATIC_DIR, author_review)
                        shutil.copytree(src_path, dst_path)

                    elif ars == 'nc' and cs == 'C1':
                        file_path=f'author_review/{a_num}'
                        author_review += f'_{cs}'
                        src_path = os.path.join(settings.STATIC_DIR, file_path)
                        dst_path = os.path.join(settings.STATIC_DIR, author_review)
                        shutil.copytree(src_path, dst_path)

                    messages.success(request,"sucessfully file was compleated")
                    return redirect('author_review_process')

                else:
                    messages.warning(request,"Author should give the status")
                    return redirect('author_review_process')    
        else:
            messages.warning(request,"Please Close your break time")
            return redirect('author_review_process')


        return render(request, 'Author_review/ar_complete_process_update_end.html',{'articles':articles,'form':form})









