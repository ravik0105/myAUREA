from django.db import models
from inventory.models import Inventory_Upload
from django.conf import settings
from django.db import models
from django.db import IntegrityError
from django.urls import reverse
from django.contrib.auth.models import User
from django.utils import timezone
from django.db.models import Q
#from froala_editor.fields import FroalaField


# Create your models here.
class Author_review(models.Model):
    article_id = models.ForeignKey(Inventory_Upload, on_delete=models.DO_NOTHING)
    user_name = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.CASCADE,blank=True, null=True, limit_choices_to={'is_staff': True})
    start_date =models.DateTimeField(blank=True, null=True)
    end_date = models.DateTimeField(blank=True, null=True)
    FILE_STATUS = (
        ('q', 'Query'),
        ('a', 'Open'),
        ('h', 'Hold'),
        ('c', 'Closed'),
        ('p', 'Pause'),
        ('s', 'Start'),
    )
    filestatus = models.CharField(max_length=1,
    choices=FILE_STATUS,
    blank=True,
    default='a')
    FILE_STATUS = (
        ('cr', 'Correction'),
        ('nc', 'No Correction'),
    )
    author_review_status = models.CharField(max_length=2,
    choices=FILE_STATUS,
    blank=True, null=True, 
    default= None )

    correction_status = models.CharField(max_length=2,
    blank=True, null=True, 
    default= None )

    add_comments = models.TextField(blank=True, null=True)
    add_remarks = models.TextField(blank=True, null=True)

    def __str__(self):
        return str(self.article_id)

    class Meta:
        verbose_name_plural = "Author_review"
