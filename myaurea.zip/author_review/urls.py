from django.contrib import admin
from . import views
from . views import*
from django.views.i18n import JavaScriptCatalog
from django.urls import path
from django.core.exceptions import *


urlpatterns = [
    
        path('author_review_process/', views.author_review_process, name='author_review_process'),
        path('author_review_start/<int:pk>', views.author_review_start, name='author_review_start'),
        path('edit/<int:article_num>/<path:file_path>/', author_review_edit_file, name='author_review_edit_file'),
        path('save/<int:pk>', author_review_save_file, name='author_review_save_file'),
        path('author_review_end/<int:pk>', views.author_review_end, name="author_review_end"),
]