from django.shortcuts import redirect, render
from inventory import models as IMODEL
from .forms import*
from author_correction import models as ACMODEL
from django.contrib import messages
from django.db import connection
import os
from django.contrib.auth.models import User, Group
from django.utils.timezone import datetime
from django.utils import timezone
from django.conf import settings
from django.core.exceptions import ObjectDoesNotExist
from bs4 import BeautifulSoup
import os, re, subprocess, json, shutil
from django.http import (HttpResponse, HttpResponseBadRequest, HttpResponseForbidden)
from django.contrib.auth.decorators import login_required
from .decorators import group_required
from django.db.models import Count



@login_required
@group_required(['author_correction'])
def author_correction_process(request):
    ac_articles_available = ACMODEL.Author_correction.objects.filter(filestatus='a')
    ac_articles_process = ACMODEL.Author_correction.objects.filter(filestatus='i') or ACMODEL.Author_correction.objects.filter(filestatus='h') or ACMODEL.Author_correction.objects.filter(filestatus='p') or ACMODEL.Author_correction.objects.filter(filestatus='s') or ACMODEL.Author_correction.objects.filter(filestatus='q')
    articles_count = ACMODEL.Author_correction.objects.filter(Q(filestatus='a') | Q(filestatus='i')).annotate(count=Count('id')).order_by('filestatus').count()

    return render(request,'Author_correction/ac_process.html',{'ac_articles_available':ac_articles_available, 'ac_articles_process':ac_articles_process, 'articles_count':articles_count})


@login_required
@group_required(['author_correction'])
def author_correction_start(request,pk):
    articles = ACMODEL.Author_correction.objects.get(id=pk)
    a = articles.article_id

    article_id_ID = IMODEL.Inventory_Upload.objects.get(article_id=a).pk
    user = request.user
    u_name = User.objects.get(username=user).pk
    start_date = timezone.now().strftime('%Y-%m-%d %H:%M:%S')
    sta = 'i'
    act ='AUCR'
    articles.user_name=user
    articles.start_date=start_date
    articles.filestatus=sta
    cs = articles.correction_status

    cursor = connection.cursor()

    author_correction_update_process= "UPDATE Process_status_process_status SET start_date='%s', filestatus='i', user_name_id='%s' WHERE article_id_id='%s' and activity='%s';"
    cursor.execute(author_correction_update_process%(start_date, u_name, article_id_ID, act))

    author_correction_start_process_production = "INSERT INTO Process_status_production_hours (article_id_id,start_date,user_name_id,filestatus,activity) VALUES ('%s','%s','%s','%s','%s');"
    cursor.execute(author_correction_start_process_production%(article_id_ID,start_date,u_name,sta,act))
    articles.save()

    if cs == 'cr':
        return redirect('author_correction_edit_file', article_num = article_id_ID, file_path=f'author_correction/{a}_{cs}/{a}.html')
    else:
        return redirect('author_correction_edit_file', article_num = article_id_ID, file_path=f'author_correction/{a}_{cs}/{a}.html')

@login_required
@group_required(['author_correction'])
def author_correction_edit_file(request, article_num, file_path):
    articles = ACMODEL.Author_correction.objects.all()
    file_path = os.path.join(settings.STATIC_DIR, file_path)
    file_path = file_path.replace("\\", "/")
    with open(file_path, 'r', encoding='utf8') as f:
        file_content = f.read()
        file_content = file_content.replace('mml:','')
    return render(request, 'Author_correction/ac_edit_file.html', {'file_content': file_content, 'article_num':article_num, 'file_path': file_path, 'articles':articles})

@login_required
@group_required(['author_correction'])
def author_correction_end(request, pk):
    articles = ACMODEL.Author_correction.objects.get(id=pk)
    aa = articles.article_id
    jcode = str(aa).split('-')[0]
    inventory_upload_instance = articles.article_id
    article_title = inventory_upload_instance.title
    article_author = inventory_upload_instance.authors
#    print("article_title raviiiiiiiiiiiii",article_title)    
    file_status = articles.filestatus
    form = authour_correction_form(request.POST or None, instance=articles)  
    if file_status != 'p':        
        if form.is_valid():
            start_date = timezone.now().strftime('%Y-%m-%d %H:%M:%S')
            articles.end_date = start_date
            form.data._mutable=True
            user = request.user
            articles.user_name = user
            a = articles.article_id_id
            user = request.user
            u_name = User.objects.get(username=user).pk
            u = str(user)
            sta = 'a'
            act1 = 'AURW'
            act2 = 'TYPE'
            st = 'c'
            articles.filestatus = 'c'
            file_status = articles.filestatus
            c = articles.add_comments
            r=articles.add_remarks
            act ='AUCR'
            ar = articles.author_review_status
            cs = articles.correction_status

            cursor = connection.cursor()

            try:
                author_correction_end_update_inuse= "UPDATE Process_status_process_status SET end_date='%s', filestatus='%s'  WHERE  article_id_id='%s' AND activity='%s' AND filestatus = 'i';"
                cursor.execute(author_correction_end_update_inuse%(start_date,st,a,act))

                author_correction_end_update_resume= "UPDATE Process_status_process_status SET end_date='%s', filestatus='%s'  WHERE  article_id_id='%s' AND activity='%s' AND filestatus = 's';"
                cursor.execute(author_correction_end_update_resume%(start_date,st,a,act))

                author_correction_start_process_end1= "UPDATE Process_status_production_hours SET end_date='%s', filestatus='c'  WHERE  article_id_id='%s' AND filestatus='i' AND activity='AUCR';"
                cursor.execute(author_correction_start_process_end1%(start_date,a))

                if articles.author_review_status == 'cr':
                    author_correction_user_end_Na = "INSERT INTO author_review_Author_review(filestatus, author_review_status, correction_status, add_comments, add_remarks, article_id_id) VALUES ('%s','%s','%s','%s','%s','%s');"
                    cursor.execute(author_correction_user_end_Na%(sta, ar, cs, c, r, a))

                    author_correction_user_end_Na_process = "INSERT INTO Process_status_process_status (filestatus, author_review_status, correction_status, activity,article_id_id) VALUES ('%s','%s','%s','%s','%s');"
                    cursor.execute(author_correction_user_end_Na_process%(sta, ar, cs, act1, a))
                else:
                    author_correction_user_end_Na = "INSERT INTO Typeset_Typeset(filestatus, add_comments, add_remarks, article_id_id) VALUES ('%s','%s','%s','%s');"
                    cursor.execute(author_correction_user_end_Na%(sta, c, r, a))

                    author_correction_user_end_Na_process = "INSERT INTO Process_status_process_status (filestatus,activity,article_id_id) VALUES ('%s','%s','%s');"
                    cursor.execute(author_correction_user_end_Na_process%(sta,act2,a))

            except ObjectDoesNotExist:
                return HttpResponse("<h2> current article is not present in database / already moved to next activity </h2>")

            form.save()
            a = articles.article_id
            cs = articles.correction_status

            if articles.author_review_status == 'cr':
                src_path1 = os.path.join(settings.STATIC_DIR, f'author_correction\\{a}_{cs}')
                dst_path1 = os.path.join(settings.STATIC_DIR, f'author_review\\{a}_{cs}')
                shutil.copytree(src_path1, dst_path1)
            else:
#                src_path2 = os.path.join(settings.STATIC_DIR, f'author_correction\\{a}_{cs}')
#                dst_path2 = os.path.join(settings.STATIC_DIR, f'Typeset\\{a}')
#                shutil.copytree(src_path2, dst_path2)

                aa = str(aa)
                aa_update_file_name = aa +'_'+ cs
                print("double aaaaaaaaaaaa",aa)
                file_path=f'author_correction/{aa_update_file_name}'
                typeset = f'Typeset/{aa}'

                l2_html_file_name=f'author_correction/{aa_update_file_name}/{aa}.html'
                type_html_file_name=f'Typeset/{aa}/{aa}.html'

                l2_html_file_name = os.path.join(settings.STATIC_DIR, l2_html_file_name)
                type_html_file_name = os.path.join(settings.STATIC_DIR, type_html_file_name)


                src_path = os.path.join(settings.STATIC_DIR, file_path)
                dst_path = os.path.join(settings.STATIC_DIR, typeset)
                shutil.copytree(src_path, dst_path)


                with open(l2_html_file_name, 'r', encoding='utf8') as f:
                    file_content = f.read()
        #            beatysoup = BeautifulSoup(file_content, 'html.parser')
                    beatysoup = BeautifulSoup(file_content, 'html5lib')
                    delete_comments = beatysoup.find_all('span', attrs={'data-tracking-deleted': 'true'})
                    delete_comments_x = beatysoup.find_all('span', attrs={'class': 'comment-delete-button'})
                    del_comments = delete_comments + delete_comments_x
                    for span in del_comments:
                        span.extract()
        #            author_tag = beatysoup.find_all('p', attrs={'author_group'})
                    file_content = file_content.replace('mml:','')
                with open(type_html_file_name, 'w', encoding='utf8') as wf:
                    content = str(beatysoup)
                    content = re.sub(r'<p class="article_title">(.*?)</p>', '<span class="article_title">\\1</span>\n', content)
                    content = re.sub(r'<p class="author_group">(.*?)</p>', '\n<span class="author_group">\\1</span>\n', content)
                    content = re.sub(r'<p class="affiliation">(.*?)</p>', '<span class="affiliation">\\1</span>\n', content)
                    content = re.sub(r'<p class="correspondance">(.*?)</p>', '<span class="correspondance">\\1</span>\n', content)
                    content = re.sub(r'<p class="abstract">(.*?)</p>', '<span class="abstract">\\1</span>\n', content)
                    content = re.sub(r'<p class="keywords">(.*?)</p>', '<span class="keywords">\\1</span>\n', content)
                    content = re.sub(r'<span data-track-id="pending-1-1" data-tracking="true">([^<]*)</span>', '\\1', content, flags=re.DOTALL)
                    content = re.sub(r'<span class="fr-tracking-deleted" contenteditable="false" data-tracking-deleted="true">(.*?)</span>', '', content, flags=re.DOTALL)
                    content = re.sub(r'<span class="fr-highlight-change" data-track-id="pending-1-2" data-tracking="true"></span>', '', content, flags=re.DOTALL)
                    content = re.sub(r'<h([0-9])><span class="fr-highlight-change" data-track-id="pending[-0-9]+" data-tracking="true">(.*?)</span></h', '<h\\1>\\2</h', content, flags=re.DOTALL)
                    content = re.sub(r'<span data-track-id="pending[^"]*" data-tracking="true"></span>', '', content, flags=re.DOTALL)
                    content = re.sub(r'src="http://127.0.0.1:8000/static/L[1-4]Edit/.*?/media/', 'src="media/', content, flags=re.DOTALL)
                    content = re.sub('<p\s?[^>]*><br></p>', '', content, flags=re.DOTALL)
                    content = content.replace('<span class="comments-button">&#x1F4AC;</span>', "")
                    content = content.replace('<span class="comment-delete-button" onclick="showConfirmationDialog(this)"> &#x2716;</span>', "")
                    content = content.replace('<span class="comment-delete-button" onclick="showConfirmationDialog(this)">&#x2716;</span>', "")
                    content = content.replace('<span class="comments-button">💬</span>', "")
                    content = content.replace('<span class="comment-delete-button" onclick="showConfirmationDialog(this)"> ✖</span>', "")
                    content = content.replace('<span class="comment-delete-button" onclick="showConfirmationDialog(this)">✖</span>', "")
#References replace
                    content = content.replace('<authors>', '&lt;authors&lt;')
                    content = content.replace('</authors>', '&lt;/authors&lt;')
                    content = content.replace('<auth>', '&lt;auth&lt;')
                    content = content.replace('</auth>', '&lt;/auth&lt;')
                    content = content.replace('<fname>', '&lt;fname&lt;')
                    content = content.replace('</fname>', '&lt;/fname&lt;')
                    content = content.replace('<lname>', '&lt;lname&lt;')
                    content = content.replace('</lname>', '&lt;/lname&lt;')
                    content = content.replace('<article_title>', '&lt;article_title&lt;')
                    content = content.replace('</article_title>', '&lt;/article_title&lt;')
                    content = content.replace('<em>', '&lt;em&lt;')
                    content = content.replace('</em>', '&lt;/em&lt;')
                    content = content.replace('<journal_title>', '&lt;journal_title&lt;')
                    content = content.replace('</journal_title>', '&lt;/journal_title&lt;')
                    content = content.replace('<year>', '&lt;year&lt;')
                    content = content.replace('</year>', '&lt;/year&lt;')
                    content = content.replace('<volume>', '&lt;volume&lt;')
                    content = content.replace('</volume>', '&lt;/volume&lt;')
                    content = content.replace('<issue>', '&lt;issue&lt;')
                    content = content.replace('</issue>', '&lt;/issue&lt;')
                    content = content.replace('<pg_rng>', '&lt;pg_rng&lt;')
                    content = content.replace('</pg_rng>', '&lt;/pg_rng&lt;')
                    content = content.replace('<doi>', '&lt;doi&lt;')
                    content = content.replace('</doi>', '&lt;/doi&lt;')

                    content = content.replace('<pmcid>', '&lt;pmid&lt;')
                    content = content.replace('</pmcid>', '&lt;/pmid&lt;')

                    content = re.sub('<p rend="CPS_REF_Yes">(.*?)</p>', '&lt;ref&gt;\\1&lt;/ref&gt;', content, flags=re.DOTALL)
                    content = re.sub('<div class="ref-list">(.*?)</div>', '&lt;ref-list&gt;\\1&lt;/ref-list&gt;', content, flags=re.DOTALL)
                    print(os.getcwd())
                    wf.write(content)

                html_file_path = 'static/Typeset/'+aa+'/'+aa+'.html'
                tex_file = 'static/Typeset/'+aa+'/'+aa+'.tex'
                commend = ["pandoc", "-s", html_file_path, "-o", tex_file, "--lua-filter=html-to-tex.lua", "--template=l2_custom-template.tex"]
                try:
                    subprocess.run(commend, check=True)
                    print("Latex file Conversion has been completed")
                except subprocess.CalledProcessError as e:
                    print("Conversion failed while Latex file creating. Error:", e)
                latexpre = 'l2_latexpre.bat'
                latexpost = 'l2_latexpost.bat'
                xml_file = 'static/Typeset/'+ aa +'/'+ aa + '.xml'
                try:
                    subprocess.run([latexpre, aa], shell=True)
                    subprocess.run([latexpost, aa], shell=True)
                    print("XML file Conversion has been completed")
                except subprocess.CalledProcessError as e:
                    print(f"Error executing Latexto command: {e}")

                tex_file = 'static/Typeset/'+aa+'/'+aa+'.tex'
                tex_file_backup = 'static/Typeset/'+aa+'/'+aa+'backup.tex'
                shutil.copy2(tex_file, tex_file_backup)

                type_tex_file_name = 'Typeset/'+ aa +'/'+ aa + '.tex'

                
                type_tex_file_name = os.path.join(settings.STATIC_DIR, type_tex_file_name)
                with open(type_tex_file_name, 'w') as texfile:
                    content = fr'''\def\mode{{{jcode}}}
\def\inputs{{
\jnllink{{Neuroendocrine_Science}}
\runningtitle{{{article_author}}}{{{article_title}}}
\citationauthor{{{article_author}}}
\copyrightauthor{{{article_author}}}
}}
\def\xmlfile{{{aa}.xml}}
\input d:/Django/bohr/bhors_tracking/static/firstxmlflow/journals.tex'''
                    texfile.write(content)
                
#                source_path = 'static/firstxmlflow/template.tex'


#                shutil.copy2(source_path, destination_path)

                # conversion part end

            messages.success(request,"sucessfully file was compleated")
            return redirect('author_correction_process')
    else:
        messages.warning(request,"Please Close your break time")
        return redirect('author_correction_process')            
    return render(request, 'author_correction/ac_complete_process_update_end.html',{'articles':articles,'form':form})


@login_required
@group_required(['author_correction'])
def author_correction_save_file(request, pk):
    file_content = request.POST.get('file_content')
    file_path = request.POST.get('file_path')
    with open(file_path, 'w', encoding='utf8') as f:
        f.write(file_content)
    return redirect('author_correction_edit_file', article_num=pk, file_path=file_path)
