from functools import wraps
from django.shortcuts import redirect
from django.http import HttpResponseForbidden

def is_admin_or_author_correction(user):
    return user.is_superuser or user.groups.filter(name='author_correction').exists()


def group_required(required_group_names):
    def decorator(view_func):
        @wraps(view_func)
        def wrapper(request, *args, **kwargs):
            if not request.user.is_authenticated:
                return redirect('login')

            if not is_admin_or_author_correction(request.user):
                return HttpResponseForbidden('You do not have permission to access this page.')

            if not request.user.groups.filter(name__in=required_group_names).exists():
                return HttpResponseForbidden('You do not have permission to access this page.')

            return view_func(request, *args, **kwargs)
        return wrapper
    return decorator
