from django.apps import AppConfig


class AuthorCorrectionConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'author_correction'
