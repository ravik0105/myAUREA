from django import forms
from .models import *
from django.contrib.admin.widgets import AdminDateWidget, AdminTimeWidget





class authour_correction_form(forms.ModelForm):
    #article_id = forms.CharField(disabled=True)
    class Meta:
        model=Author_correction
        fields=['author_review_status', 'correction_status', 'add_remarks', 'add_comments']
        widgets = {
        "start_date":  AdminDateWidget(),
        "start_time":  AdminTimeWidget(),
        "end_date":  AdminDateWidget(),
        "end_time":  AdminTimeWidget(),
        }
