from django.contrib import admin
from . import views
from . views import*
from django.views.i18n import JavaScriptCatalog
from django.urls import path
from django.core.exceptions import *


urlpatterns = [
        path('author_correction_process/', views.author_correction_process, name='author_correction_process'),
        path('author_correction_start/<int:pk>', views.author_correction_start, name='author_correction_start'),
        path('edit/<int:article_num>/<path:file_path>/', author_correction_edit_file, name='author_correction_edit_file'),
        path('save/<int:pk>', author_correction_save_file, name='author_correction_save_file'),
        path('author_correction_end/<int:pk>', views.author_correction_end, name="author_correction_end"),
]