from django.contrib import admin
from .models import process_status,production_hours

# Register your models here.



# admin.site.register(process_status)
# admin.site.register(production_hours)