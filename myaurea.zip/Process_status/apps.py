from django.apps import AppConfig


class ProcessStatusConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'Process_status'
