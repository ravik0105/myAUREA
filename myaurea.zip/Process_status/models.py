from django.db import models
from inventory.models import Inventory_Upload
from django.conf import settings
from django.db import models
from django.db import IntegrityError
from django.urls import reverse
from django.contrib.auth.models import User
from django.utils import timezone
from django.db.models import Q



# Create your models here.
class process_status (models.Model):
    article_id = models.ForeignKey(Inventory_Upload, on_delete=models.DO_NOTHING)
    user_name = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.CASCADE,blank=True, null=True, limit_choices_to={'is_staff': True})
    start_date =models.DateTimeField(blank=True, null=True)
    end_date = models.DateTimeField(blank=True, null=True)
    FILE_STATUS1 = (
        ('q', 'Query'),
        ('a', 'Open'),
        ('h', 'Hold'),
        ('c', 'Closed'),
    )
    filestatus = models.CharField(max_length=1,
    choices=FILE_STATUS1,
    blank=True)

    FILE_STATUS = (
        ('cr', 'Correction'),
        ('nc', 'No Correction'),
    )
    author_review_status = models.CharField(max_length=2,
    choices=FILE_STATUS,
    blank=True, null=True, 
    default= None )

    correction_status = models.CharField(max_length=2,
    blank=True, null=True, 
    default= None )

    FILE_STATUS2 = (
        ('AURW', 'Author Review'),
        ('AUCR', 'Author Correction'),
        ('L2ED', 'Copyedit'),
        ('TYPE', 'Type setting'),
        ('DIGI', 'Digitalization'),
    )
    activity = models.CharField(max_length=4,
    choices=FILE_STATUS2,
    blank=True)


    def __str__(self):
        return str(self.article_id)

    class Meta:
        verbose_name_plural = "Process status"



class production_hours (models.Model):
    article_id = models.ForeignKey(Inventory_Upload, on_delete=models.CASCADE)
    user_name = models.ForeignKey(User, on_delete=models.DO_NOTHING,blank=True, null=True, limit_choices_to={'is_staff': True})
    start_date =models.DateTimeField(blank=True, null=True)
    end_date = models.DateTimeField(blank=True, null=True)

    pause_date = models.DateTimeField(blank=True, null=True)
    pause_end_date = models.DateTimeField(blank=True, null=True)

    user_remarks = models.TextField(blank=True, null=True)

    FILE_STATUS = (
        ('q', 'Query'),
        ('i', 'Process'),
	    ('a', 'Open'),
        ('h', 'Hold'),
        ('c', 'Closed'),
    )
    filestatus = models.CharField(max_length=1,
                              choices=FILE_STATUS
                              )

    FILE_ACTIVITIES = (
        ('ARTW', 'Artwork'),
        ('L1ED', 'L1 Edit'),
        ('L2ED', 'L2 Edit'),
        ('TYPE', 'Type setting'),
        ('AUCR', 'Author correction'),
        ('AURW', 'Author review')
    )
    activity = models.CharField(max_length=4,
    choices=FILE_ACTIVITIES,
    blank=True,
    default='',
    )
    
    def __str__(self):
        return f'{self.article_id}'

    class Meta:
            verbose_name_plural= "Production_Hours"
