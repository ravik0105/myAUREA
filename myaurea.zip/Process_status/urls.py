from django.contrib import admin
from . import views
from django.views.i18n import JavaScriptCatalog
from django.urls import path
from django.core.exceptions import *
urlpatterns = [

    
]