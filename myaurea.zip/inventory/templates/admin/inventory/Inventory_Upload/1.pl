if(check==true)
{
 print("dont do this");
 goto Ravi;
}
else
{
 Ravi:
 print("Dont do this ever");
}