from django import forms
from .models import Inventory_Upload


class CsvImportForm(forms.Form):
    csv_upload = forms.FileField()

class InventoryUploadForm(forms.ModelForm):
    class Meta:
        model = Inventory_Upload
        fields = ['article_id', 'title', 'authors', 'correspondance_email']
#        fields = '__all__'
