from django.contrib import admin
from . import views
from django.views.i18n import JavaScriptCatalog
from django.urls import path
from django.core.exceptions import *
from.views import *

urlpatterns = [

    path('production/', production, name='production'),
    path('csv_upload_view/', csv_upload_view, name='csv_upload_view'),
    path('add_inventory/', views.add_inventory, name='add_inventory'),
]