from django.shortcuts import render
from django.shortcuts import render, redirect
from django.contrib import messages
from .models import Inventory_Upload
from .forms import CsvImportForm
import pandas as pd
import json
import os

from .forms import InventoryUploadForm


# Create your views here.
def production(request):
    data = Inventory_Upload.objects.all()

    return render(request, 'AUREA/production.html', {'data':data})



from django.db import transaction
import logging

# Configure logging
logger = logging.getLogger(__name__)

def csv_upload_view(request):
    if request.method == 'POST':
        form = CsvImportForm(request.POST, request.FILES)
        if form.is_valid():
            csv_file = request.FILES['csv_upload']
            if not csv_file.name.endswith('.csv'):
                messages.error(request, 'The wrong file type was uploaded')
                return redirect('production')

            try:
                read_file = pd.read_csv(csv_file, sep=',')
                with transaction.atomic():  # Using a transaction to ensure atomicity
                    for _, row in read_file.iterrows():
                        Inventory_Upload.objects.update_or_create(
                            article_id=row.get('File Name'),
                            defaults={
                                'title': row.get('Artile Title'),
                                'authors': row.get('Authors'),
                                'correspondance_email': row.get('Correspondance Email'),
                                'comments': row.get('Comments'),
                                'remarks': row.get('Remark')
                            }
                        )
                messages.success(request, 'CSV file has been uploaded successfully')
            except Exception as e:
                logger.error(f"Error during CSV upload: {e}")
                messages.error(request, 'An error occurred while processing the file')

            return redirect('production')

    else:
        form = CsvImportForm()

    return render(request, 'AUREA/production.html', {'form': form})


def add_inventory(request):
    if request.method == 'POST':
        form = InventoryUploadForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect('production')
    else:
        form = InventoryUploadForm()
    return render(request, 'add_inventory.html', {'form': form})