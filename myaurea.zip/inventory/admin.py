from django.contrib import admin
from .models import Inventory_Upload
# from login.models import User
from django import forms
from django.shortcuts import redirect, render, HttpResponse,HttpResponseRedirect
import pandas as pd
import json
from django.contrib import messages
import os
from django.urls import path

class CsvImportForm(forms.Form):
    csv_upload = forms.FileField()

class Inventory_UploadAdmin(admin.ModelAdmin):
    list_display = ('article_id', 'title', 'authors', 'filestatus')
    list_filter = ('filestatus',)
    readonly_fields = ('received_date',) # Readonly fields
    search_fields = ['article_id']

    
    def formfield_for_foreignkey(self, db_field, request, **kwargs):
        if db_field.name == "user":
            kwargs["initial"] = request.user.id
            kwargs["widget"] = forms.HiddenInput()
        return super().formfield_for_foreignkey(db_field, request, **kwargs)

    def get_urls(self):
        urls = super().get_urls()
        new_urls = [
            path('upload-csv/', self.upload_csv),
         ]
        return new_urls + urls
    def upload_csv(self, request):
        if request.method == 'POST':
            csv_file = request.FILES["csv_upload"]
            if not csv_file.name.endswith('.csv'):
                messages.warning(request, 'The wrong file type was uploaded')
                return HttpResponseRedirect(request.path_info)

#            file_data = csv_file.read().decode("utf-8")
            read_file = pd.read_csv(csv_file, sep = ',')
            rowcount,columncount = read_file.shape
            jsonfile = read_file.to_json('static\csv2json\csv2json.json',indent = 1, orient ='records')
#            path = 'static\csv2json\\'
#            filename = 'csv2json.json'
            f = open('static\csv2json\csv2json.json')
            data = json.load(f)
#            data = re.sub(r'"No"', '', text)
            for i in data:

                created = Inventory_Upload.objects.update_or_create(
                article_id = i['File Name'],
                title = i['Artile Title'],
                authors = i['Authors'],
                correspondance_email = i['Correspondance Email'],
#                pages = i['Page Count'],
#                tables = i['Table Count'],
#                figures = i['Figure Count'],
                comments = i['Comments'],
                remarks = i['Remark'],
                )
                    
            return render(request, "admin/csv_upload_message.html", {'data':data,'rowcount': rowcount})
            f.close()
            os.remove('static\csv2json\csv2json.json')
            #return redirect('/admin/cpts/inventory_upload/')            
        form = CsvImportForm()
        data = {'form': form}
        return render(request, "admin/csv_upload.html", data)

    def get_queryset(self, request):
        qs = super().get_queryset(request)
        available_qs = qs.filter(filestatus__in=['a', 'i', 'p', 's', 'q', 'h'])
        count = available_qs.count()
        self.available_count = count
        return available_qs
    

    list_per_page = 20

admin.site.register(Inventory_Upload, Inventory_UploadAdmin)
