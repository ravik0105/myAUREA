from django.conf import settings
from django.db import models
from django.db import IntegrityError
from django.urls import reverse
from django.contrib.auth.models import User
from django.utils import timezone
from django.db.models import Q


class Inventory_Upload(models.Model):
    article_id = models.CharField(unique = True, max_length=50)
    title = models.CharField(max_length=200)
    authors = models.CharField(max_length=200, blank=True, null=True)
    correspondance_email = models.EmailField(blank=True, null=True)
    user = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.CASCADE, blank=True, null=True)
    pages = models.IntegerField(blank=True, null=True)
    tables = models.IntegerField(blank=True, null=True)
    figures = models.IntegerField(blank=True, null=True)
    comments = models.TextField(blank=True, null=True)
    remarks = models.TextField(blank=True, null=True)
    received_date = models.DateTimeField(default=timezone.now)
    FILE_ACTIVITIES = (
    ('INVE', 'Inventory'),
      
    )
    activity = models.CharField(max_length=4,
    choices=FILE_ACTIVITIES,
    blank=True,
    default='INVE',
    )
    FILE_STATUS = (
        ('q', 'Query'),
        ('a', 'Open'),
        ('h', 'Hold'),
        ('c', 'Closed'),
    )
    filestatus = models.CharField(max_length=1,
    choices=FILE_STATUS,
    blank=True,
    default='a')
    
    def __str__(self):
        return str(self.article_id)
    
    class Meta:
            verbose_name_plural= "Inventory Upload"
