from django.http import HttpResponseRedirect, HttpResponseForbidden
from django.urls import resolve
from django.conf import settings

class GroupMiddleware:
    def __init__(self, get_response):
        self.get_response = get_response

    def __call__(self, request):

        if request.path.startswith('/password_reset/'):
        # Allow access to password change related URLs without authentication
            return self.get_response(request)
        if request.path.startswith('/reset/'):
        # Allow access to password change related URLs without authentication
            return self.get_response(request)
        if request.path.startswith('/login/'):
            return self.get_response(request)
        
        if not request.user.is_authenticated or not request.user.is_active:
            return HttpResponseRedirect(settings.LOGIN_URL)

        required_group_names = get_required_group_names(request.path)

        if request.user.is_superuser or 'admin_group' in request.user.groups.values_list('name', flat=True):
            return self.get_response(request)

        if required_group_names and not request.user.groups.filter(name__in=required_group_names).exists():
            return HttpResponseForbidden('You do not have permission to access this page.')
        return self.get_response(request)


def get_required_group_names(path):
    if 'author_correction' in path:
        return ['author_correction']
    elif 'l2_edit' in path:
        return ['l2_edit']
    elif 'Typesetting' in path:
        return ['Typesetting']
    elif 'admin_group' in path:
        return ['admin_group']
    elif 'author_review' in path:
        return ['author_review']
    elif 'Digitalization' in path:
        return ['Digitalization']
    else:
        return []