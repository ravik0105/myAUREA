# decorators.py

from django.shortcuts import redirect
from functools import wraps


def user_in_required_groups(required_groups):
    def decorator(view_func):
        @wraps(view_func)
        def wrapper(request, *args, **kwargs):
            if not user_in_required_groups(request.user, required_groups):
                return redirect('login')
            return view_func(request, *args, **kwargs)
        return wrapper
    return decorator
