from django.contrib import auth
from django.shortcuts import redirect, render, get_object_or_404
from django.http import JsonResponse
from django.db.models import Count
from django.core.exceptions import *
from django.core.cache import cache
from Process_status import models as CMODEL
from inventory import models as INVMODEL
from collections import defaultdict
from django.http import HttpResponseRedirect, HttpResponse
import csv
from django.db.models import Q
from itertools import chain
from Process_status import models as PMODEL
from django.utils import timezone
from datetime import datetime
# from L1_edit.models import L1_Edit
from L2_edit.models import L2_Edit
from Typeset.models import Typeset
from digitalization.models import digitalization
# from Author_review.models import Author_Review
from django.views.decorators.http import require_POST
from django.db.models import Q
from django.contrib.auth import logout
from django.contrib.auth import authenticate, login
from .forms import InventoryUploadForm

def search_article(request):
    if request.method == "POST":
        searched = request.POST['searched']

        # Query for CMODEL.process_status
        process_status_articles = (
            CMODEL.process_status.objects.filter(Q(article_id__article_id=searched) | 
                                                  Q(article_id__article_id__endswith='-' + searched))
        )

        # Query for INVMODEL.Inventory_Upload
        inventory_articles = (
            INVMODEL.Inventory_Upload.objects.filter(Q(article_id=searched) |
                                                      Q(article_id__endswith='-' + searched))
        )

        # Combine the results
        articles = list(process_status_articles) + list(inventory_articles)

        # Fetching title and authors from the first matching object
        article_title_queryset = INVMODEL.Inventory_Upload.objects.filter(Q(article_id=searched) |
                                                                           Q(article_id__endswith='-' + searched)).values('title')
        article_author_queryset = INVMODEL.Inventory_Upload.objects.filter(Q(article_id=searched) |
                                                                            Q(article_id__endswith='-' + searched)).values('authors')

        # Initialize values with default values
        article_title = "No matching title found"
        article_author = "No matching author found"
        desired_value = None

        # Update values if they exist in the queryset
        if article_title_queryset.exists():
            article_title = article_title_queryset[0]['title']
        if article_author_queryset.exists():
            article_author = article_author_queryset[0]['authors']

        return render(request, 'AUREA/search_article_result.html', {'searched': searched, 'articles': articles, 'desired_value': desired_value, 'article_title': article_title, 'article_author': article_author})
    else:
        return render(request, 'AUREA/search_article.html', {})



# def search_article(request):
#     if request.method == "POST":
#         searched = request.POST['searched']

#         # Query for CMODEL.process_status
#         process_status_articles = (
#             CMODEL.process_status.objects.filter(Q(article_id__article_id=searched) | 
#                                                   Q(article_id__article_id__endswith='-' + searched))
#         )

#         # Query for INVMODEL.Inventory_Upload
#         inventory_articles = (
#             INVMODEL.Inventory_Upload.objects.filter(Q(article_id=searched) |
#                                                       Q(article_id__endswith='-' + searched))
#         )

#         # Combine the results
#         articles = list(process_status_articles) + list(inventory_articles)

#         # Fetching title and authors from the first matching object
#         article_title_queryset = INVMODEL.Inventory_Upload.objects.filter(Q(article_id=searched) |
#                                                                            Q(article_id__endswith='-' + searched)).values('title')
#         article_author_queryset = INVMODEL.Inventory_Upload.objects.filter(Q(article_id=searched) |
#                                                                             Q(article_id__endswith='-' + searched)).values('authors')

#         # Initialize values with default values
#         article_title = "No matching title found"
#         article_author = "No matching author found"
#         desired_value = None

#         # Update values if they exist in the queryset
#         if article_title_queryset.exists():
#             article_title = article_title_queryset[0]['title']
#         if article_author_queryset.exists():
#             article_author = article_author_queryset[0]['authors']

#         return render(request, 'AUREA/search_article_result.html', {'searched': searched, 'articles': articles, 'desired_value': desired_value, 'article_title': article_title, 'article_author': article_author})
#     else:
#         return render(request, 'AUREA/search_article.html', {})














@require_POST  # Ensure this view only accepts POST requests
def delete_articles(request):
    # Get the list of article IDs to delete
    article_ids = request.POST.getlist('article_ids')
    print('request.POST',request.POST)

    print("article_ids",article_ids)
    # Delete the selected articles
    INVMODEL.Inventory_Upload.objects.filter(id__in=article_ids).delete()

    # Redirect to the page with the table (or wherever you want)
    return redirect('production')


def daterangestatus(request):
    inventory_upload_data = INVMODEL.Inventory_Upload.objects.filter(filestatus='a')

    l2_edit_data = L2_Edit.objects.filter(
        Q(filestatus='i') | Q(filestatus='p') | Q(filestatus='s')
    ).select_related('article_id')

    combined_data = [
        {'type': 'Inventory_Upload', 'data': item, 'related_data': None}
        for item in inventory_upload_data
    ] + [
        {'type': 'L2_Edit', 'data': item, 'related_data': item.article_id}
        for item in l2_edit_data
    ]

    typeset_data = Typeset.objects.filter(Q(filestatus='a') | Q(filestatus='i') | Q(filestatus='p') | Q(filestatus='s')).select_related('article_id')
    Typeset_count = Typeset.objects.filter(Q(filestatus='a') | Q(filestatus='i') | Q(filestatus='p') | Q(filestatus='s')).annotate(count=Count('id')).order_by('filestatus').count()

    digitalization_data = digitalization.objects.filter(Q(filestatus='a') | Q(filestatus='i') | Q(filestatus='p') | Q(filestatus='s')).select_related('article_id')
    digitalization_count = digitalization.objects.filter(Q(filestatus='a') | Q(filestatus='i') | Q(filestatus='p') | Q(filestatus='s')).annotate(count=Count('id')).order_by('filestatus').count()

    context = {
        'combined_data': combined_data,
        'combined_count': len(combined_data),
        'typeset_data' : typeset_data,
        'typeset_count' :Typeset_count,
        'digitalization_data':digitalization_data,
        'digitalization_count':digitalization_count,
    }
    return render(request, 'AUREA/index3.html', context)


def group_based_redirect(user):
    if user.groups.filter(name='l2_edit').exists():
        return 'l2_process'
    elif user.groups.filter(name='Typesetting').exists():
        return 'typeset_process'
    elif user.groups.filter(name='Digitalization').exists():
        return 'digital_process'
    elif user.groups.filter(name='author_review').exists():
        return 'author_review_process'
    elif user.groups.filter(name='author_correction').exists():
        return 'author_correction_process'
    elif user.groups.filter(name='admin').exists():
        return 'dashboard'
    else:
        return 'login'

def login_view(request):
    if request.method == 'POST':
        username = request.POST.get('username')
        password = request.POST.get('password')
        user = authenticate(request, username=username, password=password)
        if user is not None:
            login(request, user)
            return redirect(group_based_redirect(user))
        else:
            
            return render(request, 'admin_custom/login.html', {'error': 'Invalid username or password'})
    else:
        return render(request, 'admin_custom/login.html')  


def available_inv(request):
    queryset = INVMODEL.Inventory_Upload.objects.all()
    prefix_counts = defaultdict(int)
    repeated_data = []
    for item in queryset:
        prefix = item.article_id.split('-')[0]
        prefix_counts[prefix] += 1
        if prefix_counts[prefix] > 1:
            repeated_data.append(prefix)

    unique_prefixes = set(repeated_data)

    prefix = request.GET.get('prefix')  # Get the prefix parameter from the URL

    available_articles = []
    for item in queryset:
        item_prefix = item.article_id.split('-')[0]
        if item_prefix == prefix and item.filestatus == 'a':
            available_articles.append({
                'article_id': item.article_id,
                'filestatus': item.filestatus,
                'received_date': item.received_date,
            })

    context = {
        'unique_prefixes': unique_prefixes,
        'available_articles': available_articles,
    }
    return render(request, 'inv_available.html', context)


def process_inv(request):
    queryset = CMODEL.process_status.objects.all()
    prefix_counts = defaultdict(int)
    repeated_data = []

    for item in queryset:
        prefix = item.article_id.article_id.split('-')[0]
        prefix_counts[prefix] += 1
        if prefix_counts[prefix] > 1:
            repeated_data.append(prefix)

    unique_prefixes = set(repeated_data)

    prefix = request.GET.get('prefix')

    available_articles = []
    for item in queryset:
        item_prefix = item.article_id.article_id.split('-')[0]
        if item_prefix == prefix and item.filestatus in ['i', 'p', 's', 'h']:
            available_articles.append({
                'article_id': item.article_id.article_id,
                'filestatus': item.filestatus,
                
            })

    context = {
        'unique_prefixes': unique_prefixes,
        'available_articles': available_articles,
    }
    return render(request, 'process_inv.html', context)

def process_complete(request):
    queryset = CMODEL.process_status.objects.all()
    prefix_counts = defaultdict(int)
    repeated_data = []

    for item in queryset:
        prefix = item.article_id.article_id.split('-')[0]
        prefix_counts[prefix] += 1
        if prefix_counts[prefix] > 1:
            repeated_data.append(prefix)

    unique_prefixes = set(repeated_data)

    prefix = request.GET.get('prefix')

    available_articles = []
    for item in queryset:
        item_prefix = item.article_id.article_id.split('-')[0]
        if item_prefix == prefix and item.filestatus in ['c'] and item.activity == 'DIGI':
            available_articles.append({
                'article_id': item.article_id.article_id,
                'filestatus': item.filestatus,
                
            })

    context = {
        'unique_prefixes': unique_prefixes,
        'available_articles': available_articles,
    }
    return render(request, 'process_complete.html', context)



def total_inv(request):
    queryset = INVMODEL.Inventory_Upload.objects.all()
    prefix_counts = defaultdict(int)
    repeated_data = []
    for item in queryset:
        prefix = item.article_id.split('-')[0]
        prefix_counts[prefix] += 1
        if prefix_counts[prefix] > 1:
            repeated_data.append(prefix)

    unique_prefixes = set(repeated_data)

    prefix = request.GET.get('prefix')

    available_articles = []
    for item in queryset:
        item_prefix = item.article_id.split('-')[0]
        if item_prefix == prefix and item :
            available_articles.append({
                'article_id': item.article_id,
                'filestatus': item.filestatus,
                'received_date': item.received_date,
            })

    context = {
        'unique_prefixes': unique_prefixes,
        'available_articles': available_articles,
    }
    return render(request, 'total_inv.html', context)



from django.utils import timezone
from datetime import datetime
from django.http import HttpResponse
import csv

# Assuming CMODEL is imported

def importcsv(request):
    # Retrieve filters from the request (you could also use session variables)
    field1_filter = request.GET.get('article_id', None)
    start_date = request.GET.get('start_date', None)
    end_date = request.GET.get('end_date', None)
    filestatus_filter = request.GET.get('filestatus_filter', None)
    activity_filter = request.GET.get('activity_filter', None)

    # Apply filters to the queryset
    queryset = CMODEL.process_status.objects.all()

    if field1_filter:
        queryset = queryset.filter(article_id__title__icontains=field1_filter)

    if start_date and end_date:
        start_date = timezone.make_aware(datetime.strptime(start_date, '%Y-%m-%d'))
        end_date = timezone.make_aware(datetime.strptime(end_date, '%Y-%m-%d'))
        queryset = queryset.filter(start_date__date__range=(start_date.date(), end_date.date()),
                                   end_date__date__range=(start_date.date(), end_date.date()))

    if filestatus_filter:
        queryset = queryset.filter(filestatus=filestatus_filter)

    if activity_filter:
        queryset = queryset.filter(activity=activity_filter)

    # Create the HttpResponse object with CSV header
    response = HttpResponse(content_type='text/csv')
    response['Content-Disposition'] = 'attachment; filename=process_status.csv'

    writer = csv.writer(response)
    writer.writerow(['Article IDs', 'User Name', 'Start Date', 'End Date', 'Status', 'Activity'])

    for article in queryset:
        writer.writerow([article.article_id, article.user_name, article.start_date, article.end_date, article.filestatus, article.activity])

    return response




def selectdaterange(request):
    queryset = CMODEL.process_status.objects.all()
    field1_filter = request.GET.get('article_id')
    if field1_filter:
        # queryset = queryset.filter(Q(article_id__article_id__startswith=field1_filter) | Q(article_id__article_id=field1_filter))
        queryset = queryset.filter(Q(article_id__article_id__icontains=field1_filter))

    start_date = request.GET.get('start_date')
    end_date = request.GET.get('end_date')

    if start_date and end_date:
        start_date = timezone.make_aware(datetime.strptime(start_date, '%Y-%m-%d'))
        end_date = timezone.make_aware(datetime.strptime(end_date, '%Y-%m-%d'))

        queryset = queryset.filter(start_date__date__range=(start_date.date(), end_date.date()),
                                end_date__date__range=(start_date.date(), end_date.date()))

    filestatus_filter = request.GET.get('filestatus_filter')
    if filestatus_filter:
        queryset = queryset.filter(filestatus=filestatus_filter)

    activity_filter = request.GET.get('activity_filter')
    if activity_filter:
        queryset = queryset.filter(activity=activity_filter)

    activity_choices = CMODEL.process_status.FILE_STATUS2
    filestatus_choices = CMODEL.process_status.FILE_STATUS1

    return render(request, 'AUREA/demo_daterange.html', {'queryset2':start_date, 'data': queryset, 'activity_choices': activity_choices, 'filestatus_choices': filestatus_choices})



def get_articles_by_prefix(request):
    prefix = request.GET.get('prefix', '')
    articles = CMODEL.process_status.objects.filter(article_id__article_id__startswith=prefix)
    article_data = []
    for article in articles:
        article_data.append({
            'article_id': article.article_id,
            'title': article.title,
            # Add other desired article fields
        })
    return JsonResponse(article_data, safe=False)



def tl_dashboard(request):
    dataset = CMODEL.process_status.objects.values('activity').annotate(count=Count('id')).order_by()
    dataset2 = CMODEL.process_status.objects.all()
## L1_edit start##
    prefix_counts = defaultdict(int)
    file_status_counts = defaultdict(int)
    repeated_data = []

    l1_edit_prefixes = L1_Edit.objects.values_list('article_id__article_id', flat=True).distinct()

    for prefix in l1_edit_prefixes:
        split_prefix = prefix.split('-')[0]  # Splitting the prefix by dot ('.') and taking the first part
        prefix_counts[split_prefix] += 1
        if prefix_counts[split_prefix] >= 1:
            repeated_data.append(split_prefix)

    unique_prefixes = set(repeated_data)

    file_status_counts_articles = defaultdict(int)
    process_status_counts = defaultdict(int)
    activity_data = defaultdict(list)  # Store activity data for each prefix

    for prefix in unique_prefixes:
        count_a = 0
        count_ipsh = 0
        count_c = 0

        l1_edit_objects = L1_Edit.objects.filter(article_id__article_id__startswith=prefix)
        for l1_edit in l1_edit_objects:
            if l1_edit.filestatus == 'a':
                count_a += 1
            elif l1_edit.filestatus in ['i', 'p', 's', 'h']:
                count_ipsh += 1
            elif l1_edit.filestatus == 'c':
                count_c += 1
        print(count_ipsh)
        file_status_counts_articles[prefix] = count_ipsh
        process_status_counts[prefix] = count_c

        file_status_counts[prefix] = count_a

    table_data = []

    for prefix in unique_prefixes:
        prefix_data = {
            'prefix': prefix,
            'count': file_status_counts[prefix],
            'total_articles_count': prefix_counts[prefix],
            'process_status_count': file_status_counts_articles[prefix],
            'completed_count': process_status_counts[prefix],
            'activities': {},
        }
        table_data.append(prefix_data)

    context = {
        'table_data': table_data,
    }

## L1_edit end##

    
## L2_edit start##

    prefix_counts_l2 = defaultdict(int)
    file_status_counts_l2 = defaultdict(int)
    repeated_data_l2 = []

    l2_edit_prefixes = L2_Edit.objects.values_list('article_id__article_id', flat=True).distinct()

    for prefix_l2 in l2_edit_prefixes:
        split_prefix = prefix_l2.split('-')[0]  # Splitting the prefix by dot ('.') and taking the first part
        prefix_counts_l2[split_prefix] += 1
        if prefix_counts_l2[split_prefix] >= 1:
            repeated_data_l2.append(split_prefix)

    unique_prefixes_l2 = set(repeated_data_l2)

    file_status_counts_l2_articles = defaultdict(int)
    process_status_counts = defaultdict(int)
    activity_data = defaultdict(list)  # Store activity data for each prefix

    for prefix_l2 in unique_prefixes_l2:
        count_a = 0
        count_ipsh = 0
        count_c = 0

        l2_edit_objects = L2_Edit.objects.filter(article_id__article_id__startswith=prefix_l2)
        for l2_edit in l2_edit_objects:
            if l2_edit.filestatus == 'a':
                count_a += 1
            elif l2_edit.filestatus in ['i', 'p', 's', 'h']:
                count_ipsh += 1
            elif l2_edit.filestatus == 'c':
                count_c += 1

        file_status_counts_l2_articles[prefix_l2] = count_ipsh
        process_status_counts[prefix_l2] = count_c

        file_status_counts_l2[prefix_l2] = count_a

    table_data_l2 = []
    print(table_data_l2)

    for prefix_l2 in unique_prefixes_l2:
        prefix_data = {
            'prefix_l2': prefix_l2,
            'count_l2': file_status_counts_l2[prefix_l2],
            'total_articles_count_l2': prefix_counts_l2[prefix_l2],
            'process_status_count_l2': file_status_counts_l2_articles[prefix_l2],
            'completed_count_l2': process_status_counts[prefix_l2],
            'activities': {},
        }
        table_data_l2.append(prefix_data)

    context_l2 = {
        'table_data_l2': table_data_l2,
    }

    l1_avail = L1_Edit.objects.filter(filestatus='a').annotate(count=Count('id')).order_by('filestatus').count()
    l1_inuse = L1_Edit.objects.filter(filestatus='i').annotate(count=Count('id')).order_by('filestatus').count()
    l1_pause = L1_Edit.objects.filter(filestatus='p').annotate(count=Count('id')).order_by('filestatus').count()
    l1_start = L1_Edit.objects.filter(filestatus='s').annotate(count=Count('id')).order_by('filestatus').count()

    l1_comp = L1_Edit.objects.filter(filestatus='c').annotate(count=Count('id')).order_by('filestatus').count()

    l1_edit_process= l1_inuse+ l1_pause+l1_start

    l2_avail = L2_Edit.objects.filter(filestatus='a').annotate(count=Count('id')).order_by('filestatus').count()
    l2_inuse = L2_Edit.objects.filter(filestatus='i').annotate(count=Count('id')).order_by('filestatus').count()
    l2_pause = L2_Edit.objects.filter(filestatus='p').annotate(count=Count('id')).order_by('filestatus').count()
    l2_start = L2_Edit.objects.filter(filestatus='s').annotate(count=Count('id')).order_by('filestatus').count()

    l2_comp = L2_Edit.objects.filter(filestatus='c').annotate(count=Count('id')).order_by('filestatus').count()

    l2_edit_process= l2_inuse+ l2_pause+l2_start

    Typeset_avail = Typeset.objects.filter(filestatus='a').annotate(count=Count('id')).order_by('filestatus').count()
    Typeset_inuse = Typeset.objects.filter(filestatus='i').annotate(count=Count('id')).order_by('filestatus').count()
    Typeset_pause = Typeset.objects.filter(filestatus='p').annotate(count=Count('id')).order_by('filestatus').count()
    Typeset_start = Typeset.objects.filter(filestatus='s').annotate(count=Count('id')).order_by('filestatus').count()

    Typeset_comp = Typeset.objects.filter(filestatus='c').annotate(count=Count('id')).order_by('filestatus').count()

    Typeset_edit_process= Typeset_inuse+ Typeset_pause+Typeset_start


    user_groups = request.user.groups.values_list('name', flat=True)
    # Check if the desired groups are present
    if 'l1_edit_admin' in user_groups:
        activity = 'L1ED'
    elif 'l2_edit_admin' in user_groups:
        activity = 'L2ED'
    else:
        activity = None

    # Retrieve the data based on the user's activity
    if activity is not None:
        
        dataset_tl_process = (CMODEL.process_status.objects.filter(activity=activity).values('filestatus').annotate(count= Count('id')))

        

    context = {
    
        'dataset_tl_process': dataset_tl_process,
        'activity': activity,

        'activity_data':activity_data,
        'table_data': table_data,
        'table_data_l2': table_data_l2,
        'context_l2' : context_l2,
        'l1_avail':l1_avail,
        'l1_edit_process':l1_edit_process,
        'l1_comp':l1_comp,

        # 'table_data_typeset':table_data_typeset,
        'l2_avail':l2_avail,
        'l2_edit_process':l2_edit_process,
        'l2_comp':l2_comp,

        # 'context_typeset':context_typeset,        
        'Typeset_avail':Typeset_avail,
        'Typeset_edit_process':Typeset_edit_process,
        'Typeset_comp':Typeset_comp,
        'dataset':dataset,
        'dataset2' :dataset2,

    }

    return render (request,'tldashboard.html', context)

# TL dashboard journal counts

def available_l1_edit (request):
    queryset = L1_Edit.objects.all()
    prefix_counts = defaultdict(int)
    repeated_data = []

    for item in queryset:
        prefix = item.article_id.article_id.split('-')[0]
        prefix_counts[prefix] += 1
        if prefix_counts[prefix] >= 1:
            repeated_data.append(prefix)

    unique_prefixes = set(repeated_data)

    prefix = request.GET.get('prefix')

    available_articles = []
    for item in queryset:
        item_prefix = item.article_id.article_id.split('-')[0]
        if item_prefix == prefix and item.filestatus =='a':
            available_articles.append({
                'article_id': item.article_id.article_id,
                'filestatus': item.filestatus,
                
            })

    context = {
        'unique_prefixes': unique_prefixes,
        'available_articles': available_articles,
    }
    return render(request, 'available_l1_edit.html', context)


def process_l1_edit(request):
    queryset = L1_Edit.objects.all()
    prefix_counts = defaultdict(int)
    repeated_data = []

    for item in queryset:
        prefix = item.article_id.article_id.split('-')[0]
        prefix_counts[prefix] += 1
        if prefix_counts[prefix] > 1:
            repeated_data.append(prefix)

    unique_prefixes = set(repeated_data)

    prefix = request.GET.get('prefix')

    available_articles = []
    for item in queryset:
        item_prefix = item.article_id.article_id.split('-')[0]
        if item_prefix == prefix and item.filestatus in ['i', 'p', 's', 'h']:
            available_articles.append({
                'article_id': item.article_id.article_id,
                'filestatus': item.filestatus,
                
            })

    context = {
        'unique_prefixes': unique_prefixes,
        'available_articles': available_articles,
    }
    return render(request, 'process_l1_edit.html', context)


def process_complete_l1_edit(request):
    queryset = L1_Edit.objects.all()
    prefix_counts = defaultdict(int)
    repeated_data = []

    for item in queryset:
        prefix = item.article_id.article_id.split('-')[0]
        prefix_counts[prefix] += 1
        if prefix_counts[prefix] > 1:
            repeated_data.append(prefix)

    unique_prefixes = set(repeated_data)

    prefix = request.GET.get('prefix')

    available_articles = []
    for item in queryset:
        item_prefix = item.article_id.article_id.split('-')[0]
        if item_prefix == prefix and item.filestatus in ['c']:
            available_articles.append({
                'article_id': item.article_id.article_id,
                'filestatus': item.filestatus,
                
            })

    context = {
        'unique_prefixes': unique_prefixes,
        'available_articles': available_articles,
    }
    return render(request, 'process_complete_l1_edit.html', context)



def total_l1_edit(request):
    queryset = L1_Edit.objects.all()
    prefix_counts = defaultdict(int)
    repeated_data = []
    for item in queryset:
        prefix = item.article_id.article_id.split('-')[0]
        prefix_counts[prefix] += 1
        if prefix_counts[prefix] > 1:
            repeated_data.append(prefix)

    unique_prefixes = set(repeated_data)

    prefix = request.GET.get('prefix')

    available_articles = []
    for item in queryset:
        item_prefix = item.article_id.article_id.split('-')[0]
        if item_prefix == prefix and item :
            available_articles.append({
                'article_id': item.article_id,
                'filestatus': item.filestatus,
                
            })

    context = {
        'unique_prefixes': unique_prefixes,
        'available_articles': available_articles,
    }
    return render(request, 'total_l1_edit.html', context)

#l2_edit journal list


def available_l2_edit (request):
    queryset = L2_Edit.objects.all()
    prefix_counts = defaultdict(int)
    repeated_data = []

    for item in queryset:
        prefix = item.article_id.article_id.split('-')[0]
        prefix_counts[prefix] += 1
        if prefix_counts[prefix] > 1:
            repeated_data.append(prefix)

    unique_prefixes = set(repeated_data)

    prefix = request.GET.get('prefix')

    available_articles = []
    for item in queryset:
        item_prefix = item.article_id.article_id.split('-')[0]
        if item_prefix == prefix and item.filestatus =='a':
            available_articles.append({
                'article_id': item.article_id.article_id,
                'filestatus': item.filestatus,
                
            })

    context = {
        'unique_prefixes': unique_prefixes,
        'available_articles': available_articles,
    }
    return render(request, 'available_l2_edit.html', context)


def process_L2_edit(request):
    queryset = L2_Edit.objects.all()
    prefix_counts = defaultdict(int)
    repeated_data = []

    for item in queryset:
        prefix = item.article_id.article_id.split('-')[0]
        prefix_counts[prefix] += 1
        if prefix_counts[prefix] > 1:
            repeated_data.append(prefix)

    unique_prefixes = set(repeated_data)

    prefix = request.GET.get('prefix')

    available_articles = []
    for item in queryset:
        item_prefix = item.article_id.article_id.split('-')[0]
        if item_prefix == prefix and item.filestatus in ['i', 'p', 's', 'h']:
            available_articles.append({
                'article_id': item.article_id.article_id,
                'filestatus': item.filestatus,
                
            })

    context = {
        'unique_prefixes': unique_prefixes,
        'available_articles': available_articles,
    }
    return render(request, 'process_l2_edit.html', context)


def process_complete_L2_edit(request):
    queryset = L2_Edit.objects.all()
    prefix_counts = defaultdict(int)
    repeated_data = []

    for item in queryset:
        prefix = item.article_id.article_id.split('-')[0]
        prefix_counts[prefix] += 1
        if prefix_counts[prefix] > 1:
            repeated_data.append(prefix)

    unique_prefixes = set(repeated_data)

    prefix = request.GET.get('prefix')

    available_articles = []
    for item in queryset:
        item_prefix = item.article_id.article_id.split('-')[0]
        if item_prefix == prefix and item.filestatus in ['c']:
            available_articles.append({
                'article_id': item.article_id.article_id,
                'filestatus': item.filestatus,
                
            })

    context = {
        'unique_prefixes': unique_prefixes,
        'available_articles': available_articles,
    }
    return render(request, 'process_complete_l2_edit.html', context)



def total_L2_edit(request):
    queryset = L2_Edit.objects.all()
    prefix_counts = defaultdict(int)
    repeated_data = []
    for item in queryset:
        prefix = item.article_id.article_id.split('-')[0]
        prefix_counts[prefix] += 1
        if prefix_counts[prefix] > 1:
            repeated_data.append(prefix)

    unique_prefixes = set(repeated_data)

    prefix = request.GET.get('prefix')

    available_articles = []
    for item in queryset:
        item_prefix = item.article_id.article_id.split('-')[0]
        if item_prefix == prefix and item :
            available_articles.append({
                'article_id': item.article_id,
                'filestatus': item.filestatus,
                
            })

    context = {
        'unique_prefixes': unique_prefixes,
        'available_articles': available_articles,
    } 
    return render(request, 'total_l2_edit.html', context)


def user_dashboard(request):
    ruser = request.user.pk
    
    L2_Edit_available_user = L2_Edit.objects.filter(filestatus='a',user_name_id=ruser).annotate(count=Count('id')).order_by('filestatus').count()
    L2_Edit_inu_user = L2_Edit.objects.filter(filestatus='i',user_name_id=ruser).annotate(count=Count('id')).order_by('filestatus').count()    
    L2_Edit_pass_user = L2_Edit.objects.filter(filestatus='p',user_name_id=ruser).annotate(count=Count('id')).order_by('filestatus').count()
    L2_Edit_start_user = L2_Edit.objects.filter(filestatus='s',user_name_id=ruser).annotate(count=Count('id')).order_by('filestatus').count()
    L2_Edit_com_user = L2_Edit.objects.filter(filestatus='c',user_name_id=ruser).annotate(count=Count('id')).order_by('filestatus').count()
    L2_Edit_process_user = L2_Edit_inu_user+L2_Edit_pass_user+L2_Edit_start_user

    Typeset_available_user = Typeset.objects.filter(filestatus='a',user_name_id=ruser).annotate(count=Count('id')).order_by('filestatus').count()
    Typeset_inu_user = Typeset.objects.filter(filestatus='i',user_name_id=ruser).annotate(count=Count('id')).order_by('filestatus').count()    
    Typeset_pass_user = Typeset.objects.filter(filestatus='p',user_name_id=ruser).annotate(count=Count('id')).order_by('filestatus').count()
    Typeset_start_user = Typeset.objects.filter(filestatus='s',user_name_id=ruser).annotate(count=Count('id')).order_by('filestatus').count()
    Typeset_com_user = Typeset.objects.filter(filestatus='c',user_name_id=ruser).annotate(count=Count('id')).order_by('filestatus').count()
    Typeset_process_user = Typeset_inu_user+Typeset_pass_user+Typeset_start_user


    # author_review_available_user = Author_Review.objects.filter(filestatus='a',user_name_id=ruser).annotate(count=Count('id')).order_by('filestatus').count()
    # author_review_inu_user = Author_Review.objects.filter(filestatus='i',user_name_id=ruser).annotate(count=Count('id')).order_by('filestatus').count()    
    # author_review_com_user = Author_Review.objects.filter(filestatus='c',user_name_id=ruser).annotate(count=Count('id')).order_by('filestatus').count()

    
    context = {
        'L2_Edit_available_user':L2_Edit_available_user,
        'L2_Edit_com_user':L2_Edit_com_user,
        'L2_Edit_process_user':L2_Edit_process_user,
        'Typeset_available_user':Typeset_available_user,
        'Typeset_com_user':Typeset_com_user,
        'Typeset_process_user':Typeset_process_user,

        # 'author_review_available_user':author_review_available_user,
        # 'author_review_com_user':author_review_com_user,
        # 'author_review_inu_user':author_review_inu_user,
    }

    return render (request,'user_dashboard.html',context)

def userdata_dashboard(request):
    ruser = request.user.pk

    process_statprocess_statusus= CMODEL.process_status.objects.filter(user_name_id=ruser).all()

    return render(request, 'userdashboard.html', {"process_statprocess_statusus":process_statprocess_statusus})


def logout_view(request):
    logout(request)
    # Redirect to a success page or home page after logout
    return redirect('login')

def LoginView(request):
    if request.method == 'POST':
        username = request.POST.get('username', '')
        password = request.POST.get('password', '')
        user = authenticate(request, username=username, password=password)

        if user is not None and user.is_active:
            print(f"Authenticated user: {user}")
            login(request, user)

            if user.is_superuser:
                print("User is a superuser")
               
                return redirect('/dashboard/')  # Change to your admin dashboard URL
            elif user.groups.filter(name='l1_edit').exists():
                print("User is in the 'l1_edit' group")
                
                return redirect('/user_dashboard/')
            else:
                print("User does not match any conditions")
                
                return redirect('/default_dashboard/')

        # Authentication failed
        return render(request, 'admin/index3.html', {'error_message': 'Invalid login credentials.'})

    # Render the login page for GET requests
    return render(request, 'admin/index3.html')

def delete_inventory(request, id):
    inventory_instance = get_object_or_404(INVMODEL.Inventory_Upload, id=id)
    
    if request.method == 'POST':
        inventory_instance.delete()
        return redirect('/inventory/production/')  # Redirect to the list view after deletion
    
    return render(request, 'delete_typeset.html', {'inventory_instance': inventory_instance})

def edit_inventory(request, id):
    inventory_instance = get_object_or_404(INVMODEL.Inventory_Upload, id=id)
    form = InventoryUploadForm(request.POST or None, instance=inventory_instance)
    
    if request.method == 'POST':
        if form.is_valid():
            form.save()
            return redirect('/inventory/production/')
    return render(request, 'edit_typeset.html', {'form': form, 'inventory_instance': inventory_instance})
