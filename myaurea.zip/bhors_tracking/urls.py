"""
URL configuration for bhors_tracking project.

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/4.2/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  path('', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  path('', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.urls import include, path
    2. Add a URL to urlpatterns:  path('blog/', include('blog.urls'))
"""
from django.contrib import admin
from django.urls import path,include
from django.conf import settings
from django.conf.urls.static import static
from . import views
from django.contrib.auth.views import LoginView, LogoutView
from django.contrib.auth import views as auth_views

urlpatterns = [
    path('password_change/done/', auth_views.PasswordChangeDoneView.as_view(template_name='password_reset/password_change_done.html'), name='password_change_done'),
    path('password_change/', auth_views.PasswordChangeView.as_view(template_name='password_reset/password_change.html'), name='password_change'),
    path('password_reset/done/', auth_views.PasswordResetCompleteView.as_view(template_name='password_reset/password_reset_done.html'), name='password_reset_done'),
    path('reset/<uidb64>/<token>/', auth_views.PasswordResetConfirmView.as_view(), name='password_reset_confirm'),
    path('password_reset/', auth_views.PasswordResetView.as_view(), name='password_reset'),
    path('reset/done/', auth_views.PasswordResetCompleteView.as_view(template_name='password_reset/password_reset_complete.html'), name='password_reset_complete'),

    path('admin/', admin.site.urls),
    # path('login/', LoginView.as_view(template_name='admin_custom/index.html'), name='login'),

    path('login/', views.login_view, name='login'),
    path('logout/', views.logout_view, name='logout'),
    path('search_article/', views.search_article, name='search_article'),
    path('dashboard/', views.daterangestatus, name='dashboard'),
    path('available_inv/', views.available_inv, name='available_inv'),
    path('process_inv/', views.process_inv, name='process_inv'),
    path('process_complete/', views.process_complete, name='process_complete'),
    path('total_inv/', views.total_inv, name='total_inv'),
    
    path('delete_articles/', views.delete_articles, name='delete_articles'),
    path('selectdaterange/', views.selectdaterange, name='selectdaterange'),
    path('importcsv/', views.importcsv, name='importcsv'),
    # path('process_status_view/', views.process_status_view, name='process_status_view'),
    # path('restore_session/', views.restore_session, name='restore_session'),
    path('get_articles/', views.get_articles_by_prefix, name='get_articles_by_prefix'),

    path('inventory/<int:id>/edit/', views.edit_inventory, name='edit_inventory'),
    path('inventory/<int:id>/delete/', views.delete_inventory, name='delete_inventory'),

    
    path('inventory/', include('inventory.urls')),
    path('L2_edit/', include('L2_edit.urls')),
    path('digitalization/', include('digitalization.urls')),
    path('Typeset/', include('Typeset.urls')),
    # path('Author_review/', include('Author_review.urls')),
   
    path('Process_status/', include('Process_status.urls')),
    path('Process_status/', include('Process_status.urls')),
    path('tl_dashboard/', views.tl_dashboard, name='tl_dashboard'),
    path('user_dashboard/', views.user_dashboard, name='user_dashboard'),
    path('userdata_dashboard/', views.userdata_dashboard, name='userdata_dashboard'),
    path('author_correction/', include('author_correction.urls')),
    path('author_review/', include('author_review.urls')),


]
if settings.DEBUG:
    urlpatterns += static(settings.STATIC_URL, document_root=settings.STATIC_ROOT)
    
