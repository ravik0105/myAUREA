# forms.py
from django import forms
from inventory.models import Inventory_Upload

class InventoryUploadForm(forms.ModelForm):
    class Meta:
        model = Inventory_Upload
#        fields = ['article_id','comments','remarks','filestatus']
        fields = '__all__'
